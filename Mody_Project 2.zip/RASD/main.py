import random
import requests
from bs4 import BeautifulSoup
import tkinter as tk
from tkinter import filedialog, messagebox
from pytube import YouTube
import os

# Create a basic form interface using Tkinter
def start_downloader():
    # Get the search term from user input
    search_term = entry.get()
    
    # Perform random media search
    random_archive_search(search_term)

def random_archive_search(search_term):
    sources = ['youtube', 'mediafire', 'archive', 'wayback']
    selected_source = random.choice(sources)
    
    if selected_source == 'youtube':
        random_youtube_download(search_term)
    elif selected_source == 'mediafire':
        random_mediafire_download(search_term)
    elif selected_source == 'archive':
        random_archiveorg_download(search_term)
    elif selected_source == 'wayback':
        random_wayback_download(search_term)

# Random YouTube downloader using Pytube
def random_youtube_download(search_term):
    youtube_url = f'https://www.youtube.com/results?search_query={search_term}'
    response = requests.get(youtube_url)
    soup = BeautifulSoup(response.text, 'html.parser')
    videos = soup.find_all('a', href=True)
    random_video = random.choice(videos)
    video_url = 'https://www.youtube.com' + random_video['href']
    
    try:
        yt = YouTube(video_url)
        stream = yt.streams.get_highest_resolution()
        output_path = filedialog.askdirectory()
        stream.download(output_path)
        messagebox.showinfo("Success", f"Downloaded: {yt.title}")
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Random MediaFire downloader (Placeholder)
def random_mediafire_download(search_term):
    mediafire_url = f"https://www.mediafire.com/search.php?q={search_term}"
    response = requests.get(mediafire_url)
    soup = BeautifulSoup(response.text, 'html.parser')
    links = soup.find_all('a', href=True)
    random_link = random.choice(links)
    file_url = random_link['href']
    
    # Download file from MediaFire (pseudo-code)
    # requests.download(file_url)

# Random Archive.org search downloader (Placeholder)
def random_archiveorg_download(search_term):
    archive_url = f"https://archive.org/search.php?query={search_term}"
    response = requests.get(archive_url)
    soup = BeautifulSoup(response.text, 'html.parser')
    links = soup.find_all('a', href=True)
    random_link = random.choice(links)
    file_url = "https://archive.org" + random_link['href']
    
    # Download file from Archive.org (pseudo-code)
    # requests.download(file_url)

# Random Wayback Machine downloader (Placeholder)
def random_wayback_download(search_term):
    wayback_url = f"http://web.archive.org/web/*/{search_term}"
    response = requests.get(wayback_url)
    soup = BeautifulSoup(response.text, 'html.parser')
    links = soup.find_all('a', href=True)
    random_link = random.choice(links)
    file_url = random_link['href']
    
    # Download from Wayback (pseudo-code)
    # requests.download(file_url)

# GUI setup
root = tk.Tk()
root.title("Random Media Downloader")

label = tk.Label(root, text="Enter search term:")
label.pack()

entry = tk.Entry(root)
entry.pack()

download_button = tk.Button(root, text="Start Download", command=start_downloader)
download_button.pack()

root.mainloop()
