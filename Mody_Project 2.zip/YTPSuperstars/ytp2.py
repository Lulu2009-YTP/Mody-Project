import moviepy.editor as mp
from pydub import AudioSegment
import os

class YTPCreator:
    def __init__(self, video_path, audio_path, output_path):
        self.video_path = video_path
        self.audio_path = audio_path
        self.output_path = output_path
        self.video = mp.VideoFileClip(video_path)
        self.audio = AudioSegment.from_file(audio_path)

    def apply_effects(self):
        # Example: Speed up video
        self.video = self.video.fx(mp.vfx.speedx, 1.5)
        # Example: Add a fade-in effect
        self.video = self.video.fx(mp.vfx.fadein, 2)

    def add_audio(self):
        # Combine video and audio
        final_audio = mp.AudioFileClip(self.audio_path)
        self.video = self.video.set_audio(final_audio)

    def export_video(self):
        self.video.write_videofile(self.output_path, codec='libx264', audio_codec='aac')

    def run(self):
        self.apply_effects()
        self.add_audio()
        self.export_video()

if __name__ == "__main__":
    video_path = "input_video.mp4"  # Input video file
    audio_path = "input_audio.mp3"  # Input audio file
    output_path = "output_video.mp4"  # Output video file

    ytp_creator = YTPCreator(video_path, audio_path, output_path)
    ytp_creator.run()
