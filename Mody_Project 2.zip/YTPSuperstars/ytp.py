import moviepy.editor as mp
import os
import random

def load_media(media_folder):
    media_files = {
        'videos': [],
        'audios': [],
        'images': []
    }
    for file in os.listdir(media_folder):
        if file.endswith(('.mp4', '.avi')):
            media_files['videos'].append(os.path.join(media_folder, file))
        elif file.endswith(('.mp3', '.wav')):
            media_files['audios'].append(os.path.join(media_folder, file))
        elif file.endswith(('.jpg', '.png')):
            media_files['images'].append(os.path.join(media_folder, file))
    return media_files

def create_ytp(media_files):
    clips = []

    # Randomly select videos and images
    if media_files['videos']:
        video = random.choice(media_files['videos'])
        clips.append(mp.VideoFileClip(video))

    if media_files['images']:
        image = random.choice(media_files['images'])
        img_clip = mp.ImageClip(image).set_duration(2)
        clips.append(img_clip)

    # Combine clips
    final_clip = mp.concatenate_videoclips(clips)
    return final_clip

def add_audio(final_clip, audio_file):
    if audio_file:
        audio = mp.AudioFileClip(audio_file)
        final_clip = final_clip.set_audio(audio)
    return final_clip

def export_video(final_clip, output_file):
    final_clip.write_videofile(output_file, codec='libx264')

def main():
    media_folder = 'path/to/your/media'  # Specify your media folder path
    output_file = 'output/ytp_video.mp4'  # Specify output path

    media_files = load_media(media_folder)
    final_clip = create_ytp(media_files)
    final_clip = add_audio(final_clip, random.choice(media_files['audios']) if media_files['audios'] else None)
    export_video(final_clip, output_file)

if __name__ == '__main__':
    main()
