import moviepy.editor as mp
from moviepy.video.fx.all import speedx, crop
import random

def create_ytp(input_video, output_video):
    # Load video
    video = mp.VideoFileClip(input_video)

    # Apply random speed effect
    speed_factor = random.uniform(0.5, 2.0)
    video = speedx(video, speed_factor)

    # Randomly crop the video
    start_time = random.uniform(0, video.duration - 5)
    end_time = start_time + 5
    video = crop(video, t1=start_time, t2=end_time)

    # Write the output video
    video.write_videofile(output_video, codec='libx264', audio_codec='aac')

if __name__ == "__main__":
    create_ytp('input_video.mp4', 'output_ytp.mp4')
