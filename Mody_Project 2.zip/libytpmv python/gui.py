import PySimpleGUI as sg
from ytp_generator import YTPMVGenerator

def create_ytpmv(video_path, audio_path, pitch_change, output_path):
    generator = YTPMVGenerator(video_path, audio_path)
    shifted_audio = generator.pitch_shift(pitch_change)
    generator.sync_audio_to_video()
    generator.save(output_path)

layout = [
    [sg.Text('YTPMV Generator')],
    [sg.Text('Video File'), sg.Input(), sg.FileBrowse()],
    [sg.Text('Audio File'), sg.Input(), sg.FileBrowse()],
    [sg.Text('Pitch Change (semitones)'), sg.Input()],
    [sg.Text('Output File'), sg.Input(), sg.FileSaveAs()],
    [sg.Button('Generate'), sg.Button('Cancel')]
]

window = sg.Window('YTPMV Generator', layout)

while True:
    event, values = window.read()
    if event == sg.WIN_CLOSED or event == 'Cancel':
        break
    if event == 'Generate':
        video_path = values[0]
        audio_path = values[1]
        pitch_change = int(values[2])
        output_path = values[3]
        create_ytpmv(video_path, audio_path, pitch_change, output_path)
        sg.popup('YTPMV Generated Successfully!')

window.close()
