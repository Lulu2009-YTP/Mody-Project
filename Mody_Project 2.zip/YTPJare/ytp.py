import moviepy.editor as mp
from moviepy.video.fx import speedx, fadein, fadeout

def add_video_clip(original_video, clip_to_add, position=(0, 0), duration=None):
    """Add a video clip to the original video."""
    video = mp.VideoFileClip(original_video)
    clip = mp.VideoFileClip(clip_to_add).set_position(position)
    if duration:
        clip = clip.subclip(0, duration)
    final_video = mp.CompositeVideoClip([video, clip])
    return final_video

def add_image(original_video, image_path, position=(0, 0), duration=3):
    """Add an image to the original video."""
    video = mp.VideoFileClip(original_video)
    image = mp.ImageClip(image_path).set_duration(duration).set_position(position)
    final_video = mp.CompositeVideoClip([video, image])
    return final_video

def add_audio(original_video, audio_path):
    """Add audio to the original video."""
    video = mp.VideoFileClip(original_video)
    audio = mp.AudioFileClip(audio_path)
    final_video = video.set_audio(audio)
    return final_video

def apply_effects(video_clip):
    """Apply YTP effects like speed change, fade in/out."""
    video_clip = speedx(video_clip, factor=1.5)  # Speed up the video
    video_clip = fadein(video_clip, 2)  # Fade in
    video_clip = fadeout(video_clip, 2)  # Fade out
    return video_clip

def generate_ytp(original_video, clips_to_add, images_to_add, audio_to_add):
    """Generate a YTP video by combining various elements."""
    video = mp.VideoFileClip(original_video)

    for clip in clips_to_add:
        video = add_video_clip(video, clip)

    for image in images_to_add:
        video = add_image(video, image)

    if audio_to_add:
        video = add_audio(video, audio_to_add)

    video = apply_effects(video)
    return video

# Example usage
original_video = 'input_video.mp4'
clips_to_add = ['clip1.mp4', 'clip2.mp4']
images_to_add = ['image1.png', 'image2.png']
audio_to_add = 'background_audio.mp3'

ytp_video = generate_ytp(original_video, clips_to_add, images_to_add, audio_to_add)
ytp_video.write_videofile('output_ytp.mp4', codec='libx264')
