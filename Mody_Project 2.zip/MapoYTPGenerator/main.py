import tkinter as tk
from tkinter import filedialog
from moviepy.editor import VideoFileClip, concatenate_videoclips, vfx
import random

# Function to apply random effects
def apply_random_effects(clip):
    effects = [vfx.time_mirror, vfx.fadein, vfx.fadeout, vfx.lum_contrast, vfx.mirror_x]
    random_effect = random.choice(effects)
    return clip.fx(random_effect, duration=3)

# Function to generate YTP
def generate_ytp():
    file_path = filedialog.askopenfilename(title="Select Video File")
    if not file_path:
        return
    
    # Load the video
    clip = VideoFileClip(file_path)
    
    # Apply random effects
    edited_clip = apply_random_effects(clip)
    
    # Save the final output
    output_path = filedialog.asksaveasfilename(defaultextension=".mp4", filetypes=[("MP4 files", "*.mp4")])
    if output_path:
        edited_clip.write_videofile(output_path, codec="libx264")
        tk.messagebox.showinfo("Success", "YTP Generated Successfully!")

# Tkinter GUI setup
def create_gui():
    window = tk.Tk()
    window.title("Mapo YTP Generator")
    window.geometry("400x200")

    # Create a button to generate YTP
    generate_button = tk.Button(window, text="Generate Mapo YTP", command=generate_ytp)
    generate_button.pack(pady=20)

    # Run the Tkinter window
    window.mainloop()

# Run the GUI
if __name__ == "__main__":
    create_gui()
