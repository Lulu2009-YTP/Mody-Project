import tkinter as tk
from tkinter import filedialog, messagebox
from moviepy.editor import VideoFileClip, concatenate_videoclips, vfx
import random

class YTPGenerator:
    def __init__(self, root):
        self.root = root
        self.root.title("YTP Chaos Generator Beta")
        
        # GUI Layout
        self.file_label = tk.Label(root, text="No file selected", width=50)
        self.file_label.pack(pady=10)

        self.select_button = tk.Button(root, text="Select Video", command=self.load_video)
        self.select_button.pack(pady=10)

        self.generate_button = tk.Button(root, text="Generate YTP", command=self.generate_ytp, state=tk.DISABLED)
        self.generate_button.pack(pady=10)

        self.preview_button = tk.Button(root, text="Preview YTP", command=self.preview_ytp, state=tk.DISABLED)
        self.preview_button.pack(pady=10)
        
        self.video_clip = None
        self.edited_clip = None

    def load_video(self):
        filepath = filedialog.askopenfilename(title="Select Video", filetypes=[("MP4 files", "*.mp4")])
        if filepath:
            self.file_label.config(text=filepath)
            self.video_clip = VideoFileClip(filepath)
            self.generate_button.config(state=tk.NORMAL)
        else:
            messagebox.showerror("Error", "No file selected!")

    def generate_ytp(self):
        if not self.video_clip:
            return
        
        # YTP Chaos Logic: Random effects
        duration = self.video_clip.duration
        chaos_clips = []
        
        for _ in range(5):  # Create 5 chaotic segments
            start = random.uniform(0, duration - 1)
            end = min(duration, start + random.uniform(0.5, 3))  # Random segment between 0.5 to 3 seconds
            subclip = self.video_clip.subclip(start, end)
            
            # Apply random effects
            if random.choice([True, False]):
                subclip = subclip.fx(vfx.time_mirror)  # Reverse effect
            
            if random.choice([True, False]):
                speed_factor = random.uniform(0.5, 2)
                subclip = subclip.fx(vfx.speedx, factor=speed_factor)  # Speed up or slow down
            
            chaos_clips.append(subclip)
        
        self.edited_clip = concatenate_videoclips(chaos_clips)
        self.preview_button.config(state=tk.NORMAL)

    def preview_ytp(self):
        if self.edited_clip:
            self.edited_clip.preview()
        else:
            messagebox.showerror("Error", "Generate the YTP first!")
            
if __name__ == "__main__":
    root = tk.Tk()
    app = YTPGenerator(root)
    root.mainloop()
