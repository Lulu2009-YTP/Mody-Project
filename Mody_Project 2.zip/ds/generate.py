import wx
import moviepy.editor as mp
from moviepy.video.fx import resize, crop
from PIL import Image
import os

class YTPGenerator(wx.Frame):
    def __init__(self, *args, **kw):
        super(YTPGenerator, self).__init__(*args, **kw)

        # Create a panel
        panel = wx.Panel(self)

        # Create a file picker to select the video
        self.video_picker = wx.FilePickerCtrl(panel, message="Select a Video File")
        
        # Create buttons
        self.process_button = wx.Button(panel, label="Process Video")
        self.exit_button = wx.Button(panel, label="Exit")

        # Create sizers
        vbox = wx.BoxSizer(wx.VERTICAL)
        vbox.Add(self.video_picker, flag=wx.EXPAND | wx.ALL, border=10)
        vbox.Add(self.process_button, flag=wx.ALL, border=10)
        vbox.Add(self.exit_button, flag=wx.ALL, border=10)
        panel.SetSizer(vbox)

        # Bind events
        self.process_button.Bind(wx.EVT_BUTTON, self.on_process)
        self.exit_button.Bind(wx.EVT_BUTTON, self.on_exit)

        # Set frame properties
        self.SetTitle("YTP Generator")
        self.SetSize((400, 300))
        self.Centre()

    def on_process(self, event):
        video_path = self.video_picker.GetPath()
        if not video_path:
            wx.MessageBox('Please select a video file!', 'Error', wx.OK | wx.ICON_ERROR)
            return

        # Load video
        clip = mp.VideoFileClip(video_path)
        
        # Apply some effects
        clip = clip.fx(resize.resize, newsize=(640, 480))
        clip = clip.fx(crop.crop, x1=50, y1=50, x2=600, y2=430)

        # Save the processed video
        output_path = os.path.splitext(video_path)[0] + '_processed.mp4'
        clip.write_videofile(output_path, codec='libx264')

        wx.MessageBox(f'Video processed and saved to {output_path}', 'Success', wx.OK | wx.ICON_INFORMATION)

    def on_exit(self, event):
        self.Close()

def main():
    app = wx.App()
    frame = YTPGenerator(None)
    frame.Show()
    app.MainLoop()

if __name__ == "__main__":
    main()
