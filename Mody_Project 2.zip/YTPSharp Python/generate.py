import os
from moviepy.editor import *

# Set the video and audio files
video_file = "input_video.mp4"
audio_file = "input_audio.mp3"

# Load the video and audio files
video = VideoFileClip(video_file)
audio = AudioFileClip(audio_file)

# Set the YTPSharp parameters
ytp_params = {
    "speed": 1.5,  # Speed up the video by 50%
    "pitch": 1.2,  # Increase the audio pitch by 20%
    "volume": 1.5,  # Increase the audio volume by 50%
    "reverse": False,  # Don't reverse the video
    "loop": 2  # Loop the video 2 times
}

# Apply YTPSharp effects to the video and audio
video = video.set_speed(ytp_params["speed"])
audio = audio.set_pitch(ytp_params["pitch"])
audio = audio.set_volume(ytp_params["volume"])

# If loop is enabled, duplicate the video and audio
if ytp_params["loop"] > 1:
    video = concatenate_videoclips([video] * ytp_params["loop"])
    audio = concatenate_audioclips([audio] * ytp_params["loop"])

# If reverse is enabled, reverse the video and audio
if ytp_params["reverse"]:
    video = video.reverse()
    audio = audio.reverse()

# Combine the video and audio
final_video = video.set_audio(audio)

# Write the output video file
final_video.write_videofile("output_ytp_video.mp4")