from form import create_form
from randomizer import apply_random_effects

def main():
    form = create_form()
    form.mainloop()

if __name__ == "__main__":
    main()
