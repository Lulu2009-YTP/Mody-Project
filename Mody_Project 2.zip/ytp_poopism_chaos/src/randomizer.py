import random
from effects import apply_effects

def apply_random_effects(video_path):
    # Example logic to randomize video effects
    effects = ['zoom', 'glitch', 'reverse', 'pitch_shift']
    random_effects = random.sample(effects, k=random.randint(1, len(effects)))

    for effect in random_effects:
        apply_effects(video_path, effect)
