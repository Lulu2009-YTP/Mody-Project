from moviepy.editor import VideoFileClip, AudioFileClip

def generate_ytpmv(video_file, audio_file, pitch=1.0, effect=None):
    video = VideoFileClip(video_file)
    audio = AudioFileClip(audio_file).fx(vfx.speedx, pitch)

    # Apply effects if any (you can extend this with your custom effects)
    if effect == 'Effect1':
        video = video.fx(vfx.mirror_x)
    elif effect == 'Effect2':
        video = video.fx(vfx.invert_colors)

    # Set audio to video
    video = video.set_audio(audio)

    # Export the final YTPMV
    output_file = 'output/ytpmv_final.mp4'
    video.write_videofile(output_file)

    return output_file
