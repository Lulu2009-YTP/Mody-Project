import tkinter as tk
from tkinter import ttk
from moviepy.editor import VideoFileClip
import moviepy.video.fx.all as vfx

class YTPGenerator:
    def __init__(self, master):
        self.master = master
        master.title("YTP+ [beta]")

        # Create the video player frame
        self.video_frame = tk.Frame(master)
        self.video_frame.pack(side="top", fill="both", expand=True)

        # Create the video player
        self.video_player = tk.Label(self.video_frame)
        self.video_player.pack(side="top", fill="both", expand=True)

        # Create the control frame
        self.control_frame = tk.Frame(master)
        self.control_frame.pack(side="bottom", fill="x")

        # Create the pooping style frame
        self.pooping_style_frame = tk.Frame(self.control_frame)
        self.pooping_style_frame.pack(side="left", padx=10)

        # Create the pooping style label
        self.pooping_style_label = tk.Label(self.pooping_style_frame, text="Pooping Style")
        self.pooping_style_label.pack(side="top")

        # Create the imaperson slider
        self.imaperson_slider = ttk.Scale(self.pooping_style_frame, from_=0, to=100, orient="horizontal", command=self.update_imaperson)
        self.imaperson_slider.pack(side="top", fill="x")

        # Create the imaperson label
        self.imaperson_label = tk.Label(self.pooping_style_frame, text="Imaperson:")
        self.imaperson_label.pack(side="top")

        # Create the waxonator slider
        self.waxonator_slider = ttk.Scale(self.pooping_style_frame, from_=0, to=100, orient="horizontal", command=self.update_waxonator)
        self.waxonator_slider.pack(side="top", fill="x")

        # Create the waxonator label
        self.waxonator_label = tk.Label(self.pooping_style_frame, text="Waxonator:")
        self.waxonator_label.pack(side="top")

        # Create the reset button
        self.reset_button = tk.Button(self.pooping_style_frame, text="Reset", command=self.reset_sliders)
        self.reset_button.pack(side="top")

        # Create the ok and cancel buttons
        self.ok_button = tk.Button(self.control_frame, text="OK", command=self.apply_effects)
        self.ok_button.pack(side="right", padx=10)

        self.cancel_button = tk.Button(self.control_frame, text="Cancel", command=self.cancel)
        self.cancel_button.pack(side="right", padx=10)

        # Load the video
        self.video = VideoFileClip("your_video.mp4")
        self.update_video()

    def update_imaperson(self, value):
        self.imaperson_value = int(value)
        self.update_video()

    def update_waxonator(self, value):
        self.waxonator_value = int(value)
        self.update_video()

    def reset_sliders(self):
        self.imaperson_slider.set(0)
        self.waxonator_slider.set(0)
        self.update_video()

    def update_video(self):
        # Apply imaperson and waxonator effects
        video = self.video.copy()
        video = video.fx(vfx.imaperson, self.imaperson_value / 100)
        video = video.fx(vfx.waxonator, self.waxonator_value / 100)

        # Display the updated video
        self.video_player.config(image=video.get_frame(0))
        video.close()

    def apply_effects(self):
        # Apply the imaperson and waxonator effects to the video
        self.video = self.video.fx(vfx.imaperson, self.imaperson_value / 100)
        self.video = self.video.fx(vfx.waxonator, self.waxonator_value / 100)

        # Save the modified video
        self.video.write_videofile("modified_video.mp4")

        # Close the window
        self.master.destroy()

    def cancel(self):
        # Close the window
        self.master.destroy()

root = tk.Tk()
app = YTPGenerator(root)
root.mainloop()