import tkinter as tk
from tkinter import ttk, filedialog

class YTPMVPlusApp(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("YTPMV+")
        self.geometry("400x300")

        # Browse Sources Button
        self.browse_sources_btn = ttk.Button(self, text="Browse Sources", command=self.browse_file)
        self.browse_sources_btn.grid(row=0, column=0, padx=10, pady=10)

        # Browse Audio Button
        self.browse_audio_btn = ttk.Button(self, text="Browse Audio", command=self.browse_file)
        self.browse_audio_btn.grid(row=1, column=0, padx=10, pady=10)

        # Listbox to show selected file
        self.file_listbox = tk.Listbox(self, height=3)
        self.file_listbox.grid(row=0, column=1, rowspan=2, padx=10, pady=10)

        # Selected Plugins Checkbuttons
        self.plugins_frame = ttk.LabelFrame(self, text="Selected Plugins")
        self.plugins_frame.grid(row=2, column=0, columnspan=2, padx=10, pady=10)

        self.cookie_cutter_var = tk.BooleanVar()
        self.cookie_cutter_chk = ttk.Checkbutton(self.plugins_frame, text="Cookie Cutter", variable=self.cookie_cutter_var)
        self.cookie_cutter_chk.grid(row=0, column=0)

        self.checkerboard_var = tk.BooleanVar()
        self.checkerboard_chk = ttk.Checkbutton(self.plugins_frame, text="Checkerboard", variable=self.checkerboard_var)
        self.checkerboard_chk.grid(row=0, column=1)

        self.chroma_key_var = tk.BooleanVar()
        self.chroma_key_chk = ttk.Checkbutton(self.plugins_frame, text="Chroma Key", variable=self.chroma_key_var)
        self.chroma_key_chk.grid(row=1, column=0)

        self.cc_cylinder_var = tk.BooleanVar()
        self.cc_cylinder_chk = ttk.Checkbutton(self.plugins_frame, text="CC Cylinder", variable=self.cc_cylinder_var)
        self.cc_cylinder_chk.grid(row=1, column=1)

        self.auto_flip_var = tk.BooleanVar()
        self.auto_flip_chk = ttk.Checkbutton(self.plugins_frame, text="Automatic Screen Flip", variable=self.auto_flip_var)
        self.auto_flip_chk.grid(row=2, column=0)

        # Progress bar
        self.progress_bar = ttk.Progressbar(self, orient="horizontal", length=300, mode="determinate")
        self.progress_bar.grid(row=3, column=0, columnspan=2, padx=10, pady=10)

        # Placeholder buttons for "OK" and "Cancel"
        self.ok_btn = ttk.Button(self, text="OK", command=self.start_processing)
        self.ok_btn.grid(row=4, column=0, padx=10, pady=10)

        self.cancel_btn = ttk.Button(self, text="Cancel", command=self.quit)
        self.cancel_btn.grid(row=4, column=1, padx=10, pady=10)

    def browse_file(self):
        file_path = filedialog.askopenfilename()
        if file_path:
            self.file_listbox.insert(tk.END, file_path)

    def start_processing(self):
        # Simulate the "Now Generating..." part with progress bar.
        self.progress_bar["value"] = 0
        self.update_idletasks()
        for i in range(25, 101, 25):  # Increment by 25% for demo purposes
            self.progress_bar["value"] = i
            self.update_idletasks()

if __name__ == "__main__":
    app = YTPMVPlusApp()
    app.mainloop()
