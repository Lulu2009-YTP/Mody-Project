import tkinter as tk
from tkinter import filedialog, messagebox
import random
from moviepy.editor import VideoFileClip, concatenate_videoclips
import numpy as np

# Function to create chaos
def create_chaos_effects(video_path):
    # Load the video
    clip = VideoFileClip(video_path)
    duration = clip.duration

    # Generate random cuts, speed-ups, and reversed clips
    cuts = [random.uniform(0, duration) for _ in range(5)]
    cuts.sort()

    # Create a chaotic video by splitting, reversing, and speeding up parts
    clips = []
    for i in range(len(cuts) - 1):
        subclip = clip.subclip(cuts[i], cuts[i+1])
        if random.choice([True, False]):
            subclip = subclip.fx(lambda clip: clip.speedx(factor=random.uniform(1.5, 3)))
        if random.choice([True, False]):
            subclip = subclip.fx(lambda clip: clip.fx(reverse))
        clips.append(subclip)

    # Concatenate all clips together
    final_clip = concatenate_videoclips(clips)
    
    # Apply a random audio modification (lower volume for chaos)
    final_clip = final_clip.volumex(random.uniform(0.5, 1.5))
    
    # Save the video with chaos effects
    final_clip.write_videofile("chaotic_video.mp4", codec="libx264")
    return "chaotic_video.mp4"

# GUI for the app
class ChaosVideoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("YouTube Poop Chaos Creator")
        
        # GUI elements
        self.label = tk.Label(root, text="Select a Video File")
        self.label.pack(pady=10)
        
        self.file_button = tk.Button(root, text="Browse", command=self.load_file)
        self.file_button.pack(pady=5)
        
        self.start_button = tk.Button(root, text="Create Chaos", command=self.create_chaos, state=tk.DISABLED)
        self.start_button.pack(pady=10)
        
        self.status = tk.Label(root, text="")
        self.status.pack(pady=10)
        
        self.file_path = None
    
    def load_file(self):
        self.file_path = filedialog.askopenfilename(filetypes=[("Video Files", "*.mp4 *.avi *.mov")])
        if self.file_path:
            self.status.config(text=f"Loaded: {self.file_path}")
            self.start_button.config(state=tk.NORMAL)
    
    def create_chaos(self):
        if self.file_path:
            self.status.config(text="Processing chaos...")
            chaotic_video = create_chaos_effects(self.file_path)
            messagebox.showinfo("Success", f"Chaos video created: {chaotic_video}")
            self.status.config(text="Chaos created!")

# Initialize the Tkinter app
root = tk.Tk()
app = ChaosVideoApp(root)
root.geometry("300x200")
root.mainloop()
