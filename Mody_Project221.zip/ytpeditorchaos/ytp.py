import tkinter as tk
from tkinter import filedialog
from moviepy.editor import VideoFileClip, concatenate_videoclips, AudioFileClip
import random

def add_video():
    filename = filedialog.askopenfilename(title="Select Video File", filetypes=[("MP4 files", "*.mp4"), ("All files", "*.*")])
    video_label.config(text=filename)
    video_path.set(filename)

def add_audio():
    filename = filedialog.askopenfilename(title="Select Audio File", filetypes=[("MP3 files", "*.mp3"), ("All files", "*.*")])
    audio_label.config(text=filename)
    audio_path.set(filename)

def apply_effects():
    video_file = video_path.get()
    audio_file = audio_path.get()

    if video_file:
        video = VideoFileClip(video_file)
        # Apply some chaotic effects like reverse, speed changes, random cuts
        clips = []
        for _ in range(5):  # Create 5 random segments
            start = random.uniform(0, video.duration - 2)
            end = start + random.uniform(0.5, 2)
            clip = video.subclip(start, end)
            if random.random() > 0.5:
                clip = clip.fx(vfx.time_mirror)  # Reverse clip randomly
            clip = clip.speedx(factor=random.uniform(0.5, 2))  # Change speed randomly
            clips.append(clip)
        final_clip = concatenate_videoclips(clips)

        if audio_file:
            audio = AudioFileClip(audio_file)
            final_clip = final_clip.set_audio(audio)

        final_clip.write_videofile("output.mp4", codec="libx264")

        status_label.config(text="Processing Complete! Saved as output.mp4")
    else:
        status_label.config(text="Please select a video file first.")

# Setup GUI
root = tk.Tk()
root.title("YouTube Poop Chaos Creator")

# Variables
video_path = tk.StringVar()
audio_path = tk.StringVar()

# GUI Elements
tk.Label(root, text="Select a video file:").pack()
video_label = tk.Label(root, text="No file selected")
video_label.pack()
tk.Button(root, text="Add Video", command=add_video).pack()

tk.Label(root, text="Select an audio file:").pack()
audio_label = tk.Label(root, text="No file selected")
audio_label.pack()
tk.Button(root, text="Add Audio", command=add_audio).pack()

tk.Button(root, text="Apply Chaotic Effects", command=apply_effects).pack()
status_label = tk.Label(root, text="")
status_label.pack()

root.mainloop()
