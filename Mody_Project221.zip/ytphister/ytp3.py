from moviepy.editor import *

# Load video clips
clip1 = VideoFileClip("clip1.mp4").subclip(0, 5)  # First 5 seconds of clip1
clip2 = VideoFileClip("clip2.mp4").subclip(0, 5)  # First 5 seconds of clip2
clip3 = VideoFileClip("clip3.mp4").subclip(0, 5)  # First 5 seconds of clip3

# Create some funny edits
# Reverse clip1
clip1_reversed = clip1.fx(vfx.time_mirror)

# Speed up clip2
clip2_fast = clip2.fx(vfx.speedx, 1.5)

# Cut and loop clip3
clip3_looped = concatenate_videoclips([clip3] * 3)  # Loop clip3 three times

# Combine clips together with some transitions
final_video = concatenate_videoclips([clip1_reversed, clip2_fast, clip3_looped], method="compose")

# Add text overlay
txt_clip = TextClip("This is a YouTube Poop!", fontsize=70, color='white')
txt_clip = txt_clip.set_position('center').set_duration(5)

# Overlay the text on the final video
final_video = CompositeVideoClip([final_video, txt_clip])

# Write the result to a file
final_video.write_videofile("ytp_output.mp4", codec="libx264", fps=24)
