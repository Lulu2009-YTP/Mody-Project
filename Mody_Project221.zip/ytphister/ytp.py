import tkinter as tk
from tkinter import filedialog, messagebox
from moviepy.editor import *

class YTPApp:
    def __init__(self, master):
        self.master = master
        master.title("YouTube Poop Chaos Magic Beta Features")

        self.label = tk.Label(master, text="Upload Media Files")
        self.label.pack()

        self.upload_button = tk.Button(master, text="Browse", command=self.browse_files)
        self.upload_button.pack()

        self.process_button = tk.Button(master, text="Create Video", command=self.create_video)
        self.process_button.pack()

        self.file_list = []
        self.video_output = "output.mp4"

    def browse_files(self):
        files = filedialog.askopenfilenames(title="Select Media Files", filetypes=[("Video files", "*.mp4;*.avi;*.mov"), ("All files", "*.*")])
        self.file_list = list(files)
        messagebox.showinfo("Selected Files", f"Files: {self.file_list}")

    def create_video(self):
        if not self.file_list:
            messagebox.showerror("Error", "No files selected!")
            return

        clips = [VideoFileClip(file) for file in self.file_list]
        final_clip = concatenate_videoclips(clips, method="compose")
        final_clip.write_videofile(self.video_output, codec="libx264")

        messagebox.showinfo("Success", f"Video created successfully: {self.video_output}")

if __name__ == "__main__":
    root = tk.Tk()
    app = YTPApp(root)
    root.mainloop()
