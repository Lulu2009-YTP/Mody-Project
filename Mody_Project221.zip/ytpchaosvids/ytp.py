import tkinter as tk
from tkinter import filedialog, messagebox
import moviepy.editor as mp
import random

# Function to apply chaotic YTP-style effects
def apply_effects(video_path, reverse=False, speed=1, shuffle=False, noise=False):
    try:
        # Load video
        video = mp.VideoFileClip(video_path)

        # Reverse the video
        if reverse:
            video = video.fx(mp.vfx.time_mirror)

        # Speed up or slow down the video
        if speed != 1:
            video = video.fx(mp.vfx.speedx, speed)

        # Shuffle the segments
        if shuffle:
            duration = video.duration
            segments = [video.subclip(i, min(i + 1, duration)) for i in range(0, int(duration), 1)]
            random.shuffle(segments)
            video = mp.concatenate_videoclips(segments)

        # Add noise effect (randomizing brightness)
        if noise:
            video = video.fx(mp.vfx.lum_contrast, lum=random.uniform(-100, 100), contrast=random.uniform(0.5, 2))

        # Output the video
        output_path = filedialog.asksaveasfilename(defaultextension=".mp4", filetypes=[("MP4 files", "*.mp4")])
        video.write_videofile(output_path, codec='libx264')

        messagebox.showinfo("Success", "Video saved successfully!")
    except Exception as e:
        messagebox.showerror("Error", str(e))

# GUI Setup
def open_file():
    filepath = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4;*.mov;*.avi")])
    if filepath:
        filepath_var.set(filepath)

def start_processing():
    reverse = reverse_var.get()
    speed = float(speed_var.get())
    shuffle = shuffle_var.get()
    noise = noise_var.get()
    
    if not filepath_var.get():
        messagebox.showwarning("Warning", "Please select a video file.")
    else:
        apply_effects(filepath_var.get(), reverse=reverse, speed=speed, shuffle=shuffle, noise=noise)

# Main window
root = tk.Tk()
root.title("YouTube Poop Chaos Editor")

# File selection
filepath_var = tk.StringVar()
tk.Label(root, text="Selected file:").grid(row=0, column=0, padx=10, pady=5)
tk.Entry(root, textvariable=filepath_var, width=40).grid(row=0, column=1, padx=10, pady=5)
tk.Button(root, text="Browse", command=open_file).grid(row=0, column=2, padx=10, pady=5)

# Options
reverse_var = tk.BooleanVar()
tk.Checkbutton(root, text="Reverse", variable=reverse_var).grid(row=1, column=0, sticky='w', padx=10, pady=5)

speed_var = tk.StringVar(value="1")
tk.Label(root, text="Speed (e.g., 0.5 for slow, 2 for fast):").grid(row=1, column=1, padx=10, pady=5)
tk.Entry(root, textvariable=speed_var, width=10).grid(row=1, column=2, padx=10, pady=5)

shuffle_var = tk.BooleanVar()
tk.Checkbutton(root, text="Shuffle segments", variable=shuffle_var).grid(row=2, column=0, sticky='w', padx=10, pady=5)

noise_var = tk.BooleanVar()
tk.Checkbutton(root, text="Add random noise", variable=noise_var).grid(row=2, column=1, sticky='w', padx=10, pady=5)

# Process button
tk.Button(root, text="Start Chaos", command=start_processing).grid(row=3, column=0, columnspan=3, pady=20)

# Run the GUI loop
root.mainloop()
