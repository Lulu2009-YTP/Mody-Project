import tkinter as tk
from tkinter import filedialog
from moviepy.editor import VideoFileClip, concatenate_videoclips, AudioFileClip, ImageClip
import random

# Function to browse for video files
def browse_video():
    file_path = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4;*.avi;*.mov")])
    video_entry.delete(0, tk.END)
    video_entry.insert(0, file_path)

# Function to browse for audio files
def browse_audio():
    file_path = filedialog.askopenfilename(filetypes=[("Audio files", "*.mp3;*.wav")])
    audio_entry.delete(0, tk.END)
    audio_entry.insert(0, file_path)

# Function to browse for image files
def browse_image():
    file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.png;*.jpg;*.jpeg")])
    image_entry.delete(0, tk.END)
    image_entry.insert(0, file_path)

# Function to create a "YouTube Poop"-style video based on the selected style
def create_ytp():
    video_path = video_entry.get()
    audio_path = audio_entry.get()
    image_path = image_entry.get()
    style = style_var.get()

    # Load video, audio, and image
    video_clip = VideoFileClip(video_path)
    if audio_path:
        audio_clip = AudioFileClip(audio_path)
        video_clip = video_clip.set_audio(audio_clip)
    if image_path:
        image_clip = ImageClip(image_path, duration=video_clip.duration).resize(video_clip.size)
        video_clip = concatenate_videoclips([image_clip, video_clip])
    
    # Apply random effects based on the style
    if style == "YouTube Poop 2010":
        video_clip = video_clip.speedx(factor=random.uniform(0.5, 2))
    elif style == "YouTube Poop 2012":
        video_clip = video_clip.fx(vfx.mirror_x)
    elif style == "YouTube Poop 2021":
        video_clip = video_clip.volumex(random.uniform(0.5, 1.5))
    elif style == "Poopism":
        video_clip = video_clip.rotate(random.uniform(0, 360))
    elif style == "Chaos":
        video_clip = video_clip.fx(vfx.time_mirror)

    # Save the final video
    video_clip.write_videofile("output_ytp.mp4", codec="libx264")

# Create the main GUI window
root = tk.Tk()
root.title("YouTube Poop Creator")

# Video file browsing
tk.Label(root, text="Video File:").grid(row=0, column=0)
video_entry = tk.Entry(root, width=50)
video_entry.grid(row=0, column=1)
tk.Button(root, text="Browse", command=browse_video).grid(row=0, column=2)

# Audio file browsing
tk.Label(root, text="Audio File:").grid(row=1, column=0)
audio_entry = tk.Entry(root, width=50)
audio_entry.grid(row=1, column=1)
tk.Button(root, text="Browse", command=browse_audio).grid(row=1, column=2)

# Image file browsing
tk.Label(root, text="Image File:").grid(row=2, column=0)
image_entry = tk.Entry(root, width=50)
image_entry.grid(row=2, column=1)
tk.Button(root, text="Browse", command=browse_image).grid(row=2, column=2)

# YTP Style Selection
tk.Label(root, text="YTP Style:").grid(row=3, column=0)
style_var = tk.StringVar(value="YouTube Poop 2010")
style_menu = tk.OptionMenu(root, style_var, "YouTube Poop 2010", "YouTube Poop 2012", "YouTube Poop 2021", "Poopism", "Chaos")
style_menu.grid(row=3, column=1)

# Create YTP button
tk.Button(root, text="Create YTP", command=create_ytp).grid(row=4, column=1)

# Start the GUI loop
root.mainloop()
