import tkinter as tk
from tkinter import filedialog, messagebox
from moviepy.editor import VideoFileClip, AudioFileClip, concatenate_videoclips, vfx
from PIL import Image, ImageTk
import random

# Function to add "poopism" effects (e.g., random speed changes, reversing)
def apply_poopism(video_clip):
    effects = []
    
    # Randomly reverse the video
    if random.choice([True, False]):
        effects.append(video_clip.fx(vfx.time_mirror))
    
    # Randomly apply speed-up or slow-down
    if random.choice([True, False]):
        speed_factor = random.choice([0.5, 1.5, 2.0])
        effects.append(video_clip.fx(vfx.speedx, factor=speed_factor))
    
    # Return the video with effects applied (if no effects, return original)
    return random.choice(effects) if effects else video_clip

# Function to browse and load a video file
def browse_video():
    filepath = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4 *.avi *.mov")])
    if filepath:
        video_entry.delete(0, tk.END)
        video_entry.insert(0, filepath)

# Function to browse and load an audio file
def browse_audio():
    filepath = filedialog.askopenfilename(filetypes=[("Audio files", "*.mp3 *.wav")])
    if filepath:
        audio_entry.delete(0, tk.END)
        audio_entry.insert(0, filepath)

# Function to browse and load an image file
def browse_image():
    filepath = filedialog.askopenfilename(filetypes=[("Image files", "*.png *.jpg *.jpeg")])
    if filepath:
        image_entry.delete(0, tk.END)
        image_entry.insert(0, filepath)

# Function to generate the YTP-style video
def generate_ytp():
    video_path = video_entry.get()
    audio_path = audio_entry.get()
    image_path = image_entry.get()
    
    if not video_path:
        messagebox.showerror("Error", "Please select a video file.")
        return
    
    try:
        video_clip = VideoFileClip(video_path)
        
        # Apply automatic poopism
        video_clip = apply_poopism(video_clip)
        
        # Optional: overlay an image
        if image_path:
            image_clip = Image.open(image_path)
            # Convert to ImageClip (you can add an overlay here)
        
        # Optional: add an audio file
        if audio_path:
            audio_clip = AudioFileClip(audio_path)
            video_clip = video_clip.set_audio(audio_clip)
        
        # Export the final YTP video
        output_path = filedialog.asksaveasfilename(defaultextension=".mp4", filetypes=[("MP4 files", "*.mp4")])
        if output_path:
            video_clip.write_videofile(output_path, codec="libx264")
            messagebox.showinfo("Success", "YTP video generated successfully!")
    
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {str(e)}")

# Create the GUI window
root = tk.Tk()
root.title("YTP Generator 2012-Style")

# Video selection
tk.Label(root, text="Select Video:").grid(row=0, column=0, padx=10, pady=10)
video_entry = tk.Entry(root, width=50)
video_entry.grid(row=0, column=1, padx=10, pady=10)
tk.Button(root, text="Browse", command=browse_video).grid(row=0, column=2, padx=10, pady=10)

# Audio selection
tk.Label(root, text="Select Audio (optional):").grid(row=1, column=0, padx=10, pady=10)
audio_entry = tk.Entry(root, width=50)
audio_entry.grid(row=1, column=1, padx=10, pady=10)
tk.Button(root, text="Browse", command=browse_audio).grid(row=1, column=2, padx=10, pady=10)

# Image selection
tk.Label(root, text="Select Image (optional):").grid(row=2, column=0, padx=10, pady=10)
image_entry = tk.Entry(root, width=50)
image_entry.grid(row=2, column=1, padx=10, pady=10)
tk.Button(root, text="Browse", command=browse_image).grid(row=2, column=2, padx=10, pady=10)

# Generate button
tk.Button(root, text="Generate YTP", command=generate_ytp, bg="lightblue").grid(row=3, column=1, pady=20)

# Run the GUI
root.mainloop()
