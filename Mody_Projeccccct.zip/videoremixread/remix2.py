import tkinter as tk
from tkinter import filedialog, messagebox
from moviepy.editor import VideoFileClip, concatenate_videoclips, vfx
import os

class VideoRemixApp:
    def __init__(self, master):
        self.master = master
        master.title("Video Remix App")

        self.video_clips = []

        self.label = tk.Label(master, text="Video Remix Tool")
        self.label.pack()

        self.browse_button = tk.Button(master, text="Browse Video Files", command=self.browse_videos)
        self.browse_button.pack()

        self.remix_button = tk.Button(master, text="Remix Videos", command=self.remix_videos)
        self.remix_button.pack()

        self.status_label = tk.Label(master, text="")
        self.status_label.pack()

    def browse_videos(self):
        file_paths = filedialog.askopenfilenames(filetypes=[("Video Files", "*.mp4;*.avi;*.mov")])
        self.video_clips = [VideoFileClip(path) for path in file_paths]
        self.status_label.config(text=f"Loaded {len(self.video_clips)} clips.")

    def remix_videos(self):
        if not self.video_clips:
            messagebox.showerror("Error", "No video clips loaded!")
            return

        # Apply some basic remix effects (e.g., speed, cut, etc.)
        remixed_clips = []
        for clip in self.video_clips:
            # Example effect: Reverse the clip and speed it up
            remixed_clips.append(clip.fx(vfx.time_mirror).fx(vfx.speedx, 1.5))

        # Concatenate clips
        final_clip = concatenate_videoclips(remixed_clips)

        # Save the result
        output_path = os.path.join(os.getcwd(), "remixed_video.mp4")
        final_clip.write_videofile(output_path, codec="libx264")
        self.status_label.config(text=f"Remixed video saved to {output_path}")

if __name__ == "__main__":
    root = tk.Tk()
    app = VideoRemixApp(root)
    root.mainloop()
