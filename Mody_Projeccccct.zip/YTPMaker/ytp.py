import tkinter as tk
from tkinter import filedialog
from moviepy.editor import VideoFileClip, concatenate_videoclips, AudioFileClip, ImageClip
from moviepy.video.fx.all import mirror_x, mirror_y, invert_colors
import random

# Helper function to apply YTP effects
def apply_ytp_effects(video_clip):
    effects = [mirror_x, mirror_y, invert_colors]
    effect = random.choice(effects)
    return effect(video_clip)

# Main GUI window
def browse_source():
    file_path = filedialog.askopenfilename(title="Select Video File", filetypes=[("Video Files", "*.mp4 *.avi *.mov")])
    return file_path

def browse_audio():
    file_path = filedialog.askopenfilename(title="Select Audio File", filetypes=[("Audio Files", "*.mp3 *.wav")])
    return file_path

def browse_image():
    file_path = filedialog.askopenfilename(title="Select Image File", filetypes=[("Image Files", "*.jpg *.png *.jpeg")])
    return file_path

def create_pooped_video(video_path, audio_path=None, image_path=None):
    video_clip = VideoFileClip(video_path)

    # Apply YTP effects
    pooped_clip = apply_ytp_effects(video_clip)

    # Add audio if provided
    if audio_path:
        audio_clip = AudioFileClip(audio_path)
        pooped_clip = pooped_clip.set_audio(audio_clip)

    # Add image if provided
    if image_path:
        image_clip = ImageClip(image_path).set_duration(pooped_clip.duration)
        pooped_clip = concatenate_videoclips([image_clip, pooped_clip])

    # Export pooped video
    pooped_clip.write_videofile("pooped_video.mp4")

# GUI Setup
class YTPEffectApp:
    def __init__(self, root):
        self.root = root
        self.root.title("YouTube Poop Maker")

        # Browse buttons
        self.browse_video_button = tk.Button(root, text="Browse Video", command=self.load_video)
        self.browse_video_button.pack()

        self.browse_audio_button = tk.Button(root, text="Browse Audio", command=self.load_audio)
        self.browse_audio_button.pack()

        self.browse_image_button = tk.Button(root, text="Browse Image", command=self.load_image)
        self.browse_image_button.pack()

        # Button to create YTP
        self.create_ytp_button = tk.Button(root, text="Create YTP Video", command=self.create_ytp)
        self.create_ytp_button.pack()

        # File paths
        self.video_path = None
        self.audio_path = None
        self.image_path = None

    def load_video(self):
        self.video_path = browse_source()

    def load_audio(self):
        self.audio_path = browse_audio()

    def load_image(self):
        self.image_path = browse_image()

    def create_ytp(self):
        if self.video_path:
            create_pooped_video(self.video_path, self.audio_path, self.image_path)

# Main application launch
if __name__ == "__main__":
    root = tk.Tk()
    app = YTPEffectApp(root)
    root.mainloop()
