import tkinter as tk
from tkinter import filedialog, messagebox
from moviepy.editor import VideoFileClip, AudioFileClip, concatenate_videoclips
import os

class YTPApp:
    def __init__(self, master):
        self.master = master
        self.master.title("YTP Creator")
        
        # Initialize variables
        self.source_video = ""
        self.source_audio = ""
        self.source_image = ""
        
        # Create UI elements
        tk.Label(master, text="Select Source Video:").pack()
        tk.Button(master, text="Browse", command=self.browse_video).pack()

        tk.Label(master, text="Select Source Audio:").pack()
        tk.Button(master, text="Browse", command=self.browse_audio).pack()

        tk.Label(master, text="Select Image:").pack()
        tk.Button(master, text="Browse", command=self.browse_image).pack()

        tk.Button(master, text="Create YTP", command=self.create_ytp).pack()

    def browse_video(self):
        self.source_video = filedialog.askopenfilename(title="Select Video File", filetypes=[("Video Files", "*.mp4 *.avi *.mov")])
    
    def browse_audio(self):
        self.source_audio = filedialog.askopenfilename(title="Select Audio File", filetypes=[("Audio Files", "*.mp3 *.wav")])
    
    def browse_image(self):
        self.source_image = filedialog.askopenfilename(title="Select Image File", filetypes=[("Image Files", "*.jpg *.png")])
    
    def create_ytp(self):
        if not all([self.source_video, self.source_audio, self.source_image]):
            messagebox.showerror("Error", "Please select all files.")
            return

        # Load video and audio
        video = VideoFileClip(self.source_video)
        audio = AudioFileClip(self.source_audio)

        # Concatenate clips (placeholders for actual concatenation styles)
        clips = [video]  # You would add more clips based on selected styles here
        
        # Create final video
        final_video = concatenate_videoclips(clips)
        final_video.set_audio(audio)

        # Output video
        output_path = "output_ytp.mp4"
        final_video.write_videofile(output_path)
        messagebox.showinfo("Success", f"YTP created successfully: {output_path}")

if __name__ == "__main__":
    root = tk.Tk()
    app = YTPApp(root)
    root.mainloop()
