import tkinter as tk
from tkinter import filedialog, messagebox
from moviepy.editor import VideoFileClip, concatenate_videoclips

def select_file_1():
    filepath = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4 *.avi *.mov")])
    if filepath:
        file1_entry.delete(0, tk.END)
        file1_entry.insert(0, filepath)

def select_file_2():
    filepath = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4 *.avi *.mov")])
    if filepath:
        file2_entry.delete(0, tk.END)
        file2_entry.insert(0, filepath)

def concatenate_videos():
    video1_path = file1_entry.get()
    video2_path = file2_entry.get()
    
    if not video1_path or not video2_path:
        messagebox.showerror("Error", "Please select both video files.")
        return
    
    try:
        clip1 = VideoFileClip(video1_path)
        clip2 = VideoFileClip(video2_path)
        
        # Concatenating the videos
        final_clip = concatenate_videoclips([clip1, clip2])
        
        # Saving the output video
        save_path = filedialog.asksaveasfilename(defaultextension=".mp4", filetypes=[("MP4 files", "*.mp4")])
        if save_path:
            final_clip.write_videofile(save_path, codec="libx264")
            messagebox.showinfo("Success", "Videos concatenated and saved successfully!")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")

# Setting up the GUI window
root = tk.Tk()
root.title("Video Concatenation Tool")

# File 1 selection
tk.Label(root, text="Select First Video:").grid(row=0, column=0, padx=10, pady=10)
file1_entry = tk.Entry(root, width=40)
file1_entry.grid(row=0, column=1, padx=10, pady=10)
tk.Button(root, text="Browse", command=select_file_1).grid(row=0, column=2, padx=10, pady=10)

# File 2 selection
tk.Label(root, text="Select Second Video:").grid(row=1, column=0, padx=10, pady=10)
file2_entry = tk.Entry(root, width=40)
file2_entry.grid(row=1, column=1, padx=10, pady=10)
tk.Button(root, text="Browse", command=select_file_2).grid(row=1, column=2, padx=10, pady=10)

# Concatenate button
tk.Button(root, text="Concatenate Videos", command=concatenate_videos).grid(row=2, column=1, padx=10, pady=20)

# Start the GUI
root.mainloop()
