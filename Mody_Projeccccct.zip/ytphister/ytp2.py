import tkinter as tk
from tkinter import filedialog, messagebox
from moviepy.editor import VideoFileClip

class VideoEditorApp:
    def __init__(self, master):
        self.master = master
        master.title("YTP Chaos Magic Video Editor")

        self.label = tk.Label(master, text="Select a Video File:")
        self.label.pack()

        self.browse_button = tk.Button(master, text="Browse", command=self.browse_file)
        self.browse_button.pack()

        self.process_button = tk.Button(master, text="Apply Effects", command=self.apply_effects)
        self.process_button.pack()

        self.filepath = None

    def browse_file(self):
        self.filepath = filedialog.askopenfilename()
        if self.filepath:
            messagebox.showinfo("Selected File", f"You selected: {self.filepath}")

    def apply_effects(self):
        if not self.filepath:
            messagebox.showwarning("Warning", "Please select a video file first.")
            return
        
        # Here you can implement the effect processing with MoviePy
        self.process_video(self.filepath)

    def process_video(self, filepath):
        try:
            clip = VideoFileClip(filepath)
            # Example effect: reversing the video
            final_clip = clip.fx(vfx.time_mirror)  # Add more YTP effects here
            final_clip.write_videofile("output.mp4", codec='libx264')
            messagebox.showinfo("Success", "Video processed successfully!")
        except Exception as e:
            messagebox.showerror("Error", str(e))

if __name__ == "__main__":
    root = tk.Tk()
    app = VideoEditorApp(root)
    root.mainloop()
