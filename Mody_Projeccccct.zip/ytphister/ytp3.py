from moviepy.editor import VideoFileClip, concatenate_videoclips, TextClip, CompositeVideoClip, AudioFileClip
import random

# Load your video clips
clip1 = VideoFileClip("input1.mp4").subclip(0, 5)  # First 5 seconds of input1.mp4
clip2 = VideoFileClip("input2.mp4").subclip(0, 5)  # First 5 seconds of input2.mp4
clip3 = VideoFileClip("input3.mp4").subclip(0, 5)  # First 5 seconds of input3.mp4

# Create a list of clips to randomly shuffle
clips = [clip1, clip2, clip3]
random.shuffle(clips)

# Concatenate the clips together
final_clip = concatenate_videoclips(clips)

# Add a text overlay
text = TextClip("YouTube Poop!", fontsize=70, color='white', bg_color='black', size=final_clip.size)
text = text.set_position('center').set_duration(3)

# Create a composite video
video = CompositeVideoClip([final_clip, text])

# Add audio (optional)
audio = AudioFileClip("background.mp3").subclip(0, video.duration)
video = video.set_audio(audio)

# Write the result to a file
video.write_videofile("output.mp4", codec='libx264', fps=24)

# Close the clips to release resources
clip1.close()
clip2.close()
clip3.close()
video.close()
