import tkinter as tk
from tkinter import filedialog
from moviepy.editor import VideoFileClip, concatenate_videoclips

class YTPConcatApp:
    def __init__(self, root):
        self.root = root
        self.root.title("YTP Concatenator")

        self.video_paths = []
        self.audio_path = ""
        self.image_path = ""

        self.create_widgets()

    def create_widgets(self):
        tk.Button(self.root, text="Add Video", command=self.browse_video).pack(pady=5)
        tk.Button(self.root, text="Add Audio", command=self.browse_audio).pack(pady=5)
        tk.Button(self.root, text="Add Image", command=self.browse_image).pack(pady=5)
        tk.Button(self.root, text="Concat YTP", command=self.concat_ytp).pack(pady=20)

    def browse_video(self):
        file_path = filedialog.askopenfilename(title="Select Video", filetypes=[("Video Files", "*.mp4;*.avi;*.mov")])
        if file_path:
            self.video_paths.append(file_path)

    def browse_audio(self):
        self.audio_path = filedialog.askopenfilename(title="Select Audio", filetypes=[("Audio Files", "*.mp3;*.wav")])

    def browse_image(self):
        self.image_path = filedialog.askopenfilename(title="Select Image", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")])

    def concat_ytp(self):
        clips = [VideoFileClip(video) for video in self.video_paths]

        # Concatenate video clips
        final_clip = concatenate_videoclips(clips, method="compose")

        # Optionally, add audio and image processing here

        # Output the final video
        final_clip.write_videofile("output_ytp.mp4", codec="libx264")

if __name__ == "__main__":
    root = tk.Tk()
    app = YTPConcatApp(root)
    root.mainloop()
