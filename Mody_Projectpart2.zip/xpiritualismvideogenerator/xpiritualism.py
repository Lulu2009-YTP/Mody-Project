import wx
import os
from moviepy.editor import *
import random
import moviepy.video.fx.all as vfx

class XpiritualismVideoApp(wx.Frame):
    def __init__(self, *args, **kw):
        super(XpiritualismVideoApp, self).__init__(*args, **kw)

        # Set up the UI
        self.InitUI()

    def InitUI(self):
        panel = wx.Panel(self)

        vbox = wx.BoxSizer(wx.VERTICAL)

        # File picker for video
        self.filePicker = wx.FilePickerCtrl(panel, message="Select a video file")
        vbox.Add(self.filePicker, flag=wx.EXPAND|wx.ALL, border=10)

        # Button to add random effects
        self.effectBtn = wx.Button(panel, label='Apply Random Effects')
        vbox.Add(self.effectBtn, flag=wx.EXPAND|wx.ALL, border=10)

        # Bind button to event
        self.effectBtn.Bind(wx.EVT_BUTTON, self.OnApplyEffects)

        # Render Button
        self.renderBtn = wx.Button(panel, label='Render Video')
        vbox.Add(self.renderBtn, flag=wx.EXPAND|wx.ALL, border=10)

        # Bind button to render event
        self.renderBtn.Bind(wx.EVT_BUTTON, self.OnRenderVideo)

        # Output Path
        self.outputPath = wx.TextCtrl(panel, value="output.mp4", style=wx.TE_CENTRE)
        vbox.Add(self.outputPath, flag=wx.EXPAND|wx.ALL, border=10)

        panel.SetSizer(vbox)

        self.SetTitle('Xpiritualism 2008 Video Maker')
        self.Centre()

    def OnApplyEffects(self, event):
        video_path = self.filePicker.GetPath()

        if not video_path or not os.path.isfile(video_path):
            wx.MessageBox('Please select a valid video file.', 'Error', wx.OK | wx.ICON_ERROR)
            return

        self.effects = self.random_effects()
        wx.MessageBox(f'Random effects selected: {", ".join(self.effects)}', 'Effects Applied', wx.OK | wx.ICON_INFORMATION)

    def random_effects(self):
        effects_list = [
            'mirror_x', 'mirror_y', 'invert_colors', 'random_zoom', 
            'random_rotation', 'random_speed', 'random_pan', 'shake'
        ]
        return random.sample(effects_list, 3)

    def OnRenderVideo(self, event):
        video_path = self.filePicker.GetPath()
        output_path = self.outputPath.GetValue()

        if not video_path or not os.path.isfile(video_path):
            wx.MessageBox('Please select a valid video file.', 'Error', wx.OK | wx.ICON_ERROR)
            return

        # Apply effects and render
        self.render_video(video_path, output_path)
        wx.MessageBox('Video rendering complete!', 'Success', wx.OK | wx.ICON_INFORMATION)

    def render_video(self, input_video, output_video):
        clip = VideoFileClip(input_video)

        for effect in self.effects:
            if effect == 'mirror_x':
                clip = clip.fx(vfx.mirror_x)
            elif effect == 'mirror_y':
                clip = clip.fx(vfx.mirror_y)
            elif effect == 'invert_colors':
                clip = clip.fx(vfx.invert_colors)
            elif effect == 'random_zoom':
                clip = clip.fx(vfx.zoom_in, random.uniform(1.2, 1.5))
            elif effect == 'random_rotation':
                clip = clip.fx(vfx.rotate, random.randint(0, 360))
            elif effect == 'random_speed':
                clip = clip.speedx(random.uniform(0.5, 2.0))
            elif effect == 'random_pan':
                clip = clip.fx(vfx.crop, x_center=clip.w * random.uniform(0.3, 0.7), width=clip.w * 0.8)
            elif effect == 'shake':
                clip = clip.fx(vfx.shake, amplitude=5, frequency=10)

        # Save the final video
        clip.write_videofile(output_video, codec='libx264', audio_codec='aac')


if __name__ == '__main__':
    app = wx.App()
    frame = XpiritualismVideoApp(None)
    frame.Show()
    app.MainLoop()
