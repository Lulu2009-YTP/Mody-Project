import wx
import moviepy.editor as mp
from moviepy.video.fx import all as vfx
from moviepy.audio.fx import all as afx
import os

class RainbowTylenolEditor(wx.Frame):
    def __init__(self, parent, title):
        super(RainbowTylenolEditor, self).__init__(parent, title=title, size=(500, 400))

        panel = wx.Panel(self)

        # File selection
        self.file_picker = wx.FilePickerCtrl(panel, message="Select video/audio file", pos=(20, 20), size=(400, 30))
        self.effect_choice = wx.Choice(panel, choices=["Pitch Shift", "Stutter", "Color Cycle", "Zoom", "Echo", "Reverb"], pos=(20, 70), size=(200, 30))
        self.effect_choice.SetSelection(0)

        # Intensity slider
        wx.StaticText(panel, label="Effect Intensity:", pos=(20, 120))
        self.intensity_slider = wx.Slider(panel, value=50, minValue=0, maxValue=100, pos=(20, 140), size=(200, 30))

        # Duration
        wx.StaticText(panel, label="Effect Duration (seconds):", pos=(20, 180))
        self.duration_input = wx.TextCtrl(panel, value="3", pos=(20, 200), size=(100, 30))

        # Process Button
        process_button = wx.Button(panel, label="Create Rainbow Tylenol Video", pos=(20, 250))
        process_button.Bind(wx.EVT_BUTTON, self.on_process)

        # Output Log
        self.output_log = wx.TextCtrl(panel, style=wx.TE_MULTILINE | wx.TE_READONLY, pos=(20, 300), size=(450, 60))

        self.Centre()
        self.Show()

    def apply_effects(self, clip, effect, intensity, duration):
        if effect == "Pitch Shift":
            pitch_shift = intensity / 100.0 + 0.5  # More pitch shift as intensity increases
            clip = clip.fx(afx.audio_fadein, duration).fx(afx.audio_fadeout, duration).fx(afx.time_symmetrize)
            audio = clip.audio
            audio = audio.fx(afx.audio_fadein, pitch_shift)
            clip = clip.set_audio(audio)
        elif effect == "Stutter":
            stutter_time = 0.1 * (intensity / 100.0)
            clip = clip.fx(vfx.loop, duration=stutter_time, n=10)
        elif effect == "Color Cycle":
            clip = clip.fx(vfx.colorx, factor=intensity / 100.0 + 1)
        elif effect == "Zoom":
            zoom_factor = 1 + intensity / 100.0
            clip = clip.fx(vfx.resize, zoom_factor).fx(vfx.time_mirror)
        elif effect == "Echo":
            clip = clip.fx(afx.audio_fadein, duration)
        elif effect == "Reverb":
            clip = clip.fx(afx.audio_fadein, intensity / 100.0)
        return clip

    def on_process(self, event):
        file_path = self.file_picker.GetPath()
        effect = self.effect_choice.GetStringSelection()
        intensity = self.intensity_slider.GetValue()
        duration = float(self.duration_input.GetValue())

        if file_path:
            # Load the file as a MoviePy clip
            file_extension = os.path.splitext(file_path)[-1].lower()
            if file_extension in ['.mp4', '.avi', '.mov', '.wmv', '.mpeg']:
                clip = mp.VideoFileClip(file_path)
            elif file_extension in ['.mp3', '.wav', '.ogg', '.flac']:
                clip = mp.AudioFileClip(file_path)
            else:
                self.output_log.AppendText("Unsupported file format!\n")
                return

            # Apply effects
            self.output_log.AppendText(f"Applying {effect} with intensity {intensity} and duration {duration}...\n")
            processed_clip = self.apply_effects(clip, effect, intensity, duration)

            # Export the final video
            output_path = "rainbow_tylenol_output.mp4"
            processed_clip.write_videofile(output_path, codec='libx264', audio_codec='aac')
            self.output_log.AppendText(f"Video saved as {output_path}\n")
        else:
            self.output_log.AppendText("No file selected!\n")


if __name__ == '__main__':
    app = wx.App(False)
    frame = RainbowTylenolEditor(None, title="Rainbow Tylenol Video Creator")
    app.MainLoop()
