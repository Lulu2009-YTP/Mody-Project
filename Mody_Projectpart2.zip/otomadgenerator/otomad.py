import wx
from moviepy.editor import VideoFileClip, concatenate_videoclips, vfx
import ffmpeg
import os

# Define the main application window
class OtoMADApp(wx.Frame):
    def __init__(self, *args, **kw):
        super(OtoMADApp, self).__init__(*args, **kw)
        
        # Set up the GUI
        panel = wx.Panel(self)
        self.SetTitle("OtoMAD-style Video Editor")
        
        # Buttons and Text boxes for the form
        loadButton = wx.Button(panel, label='Load Video')
        loadButton.Bind(wx.EVT_BUTTON, self.on_load_video)
        
        applyEffectButton = wx.Button(panel, label='Apply Effects')
        applyEffectButton.Bind(wx.EVT_BUTTON, self.on_apply_effects)
        
        renderButton = wx.Button(panel, label='Render Video')
        renderButton.Bind(wx.EVT_BUTTON, self.on_render_video)
        
        self.effectChoice = wx.ComboBox(panel, choices=['Stutter Loop', 'Pitch Shift', 'Speed Up', 'Slow Down'], style=wx.CB_READONLY)
        self.filePathCtrl = wx.TextCtrl(panel)
        
        # Layout
        vbox = wx.BoxSizer(wx.VERTICAL)
        vbox.Add(wx.StaticText(panel, label="Video File Path:"), flag=wx.EXPAND|wx.LEFT|wx.RIGHT|wx.TOP, border=10)
        vbox.Add(self.filePathCtrl, flag=wx.EXPAND|wx.LEFT|wx.RIGHT|wx.TOP, border=10)
        vbox.Add(loadButton, flag=wx.EXPAND|wx.LEFT|wx.RIGHT|wx.TOP, border=10)
        vbox.Add(wx.StaticText(panel, label="Choose Effect:"), flag=wx.EXPAND|wx.LEFT|wx.RIGHT|wx.TOP, border=10)
        vbox.Add(self.effectChoice, flag=wx.EXPAND|wx.LEFT|wx.RIGHT|wx.TOP, border=10)
        vbox.Add(applyEffectButton, flag=wx.EXPAND|wx.LEFT|wx.RIGHT|wx.TOP, border=10)
        vbox.Add(renderButton, flag=wx.EXPAND|wx.LEFT|wx.RIGHT|wx.TOP, border=10)
        
        panel.SetSizer(vbox)
        
        self.clip = None
        self.effects_applied = []
        self.SetSize((400, 300))
    
    def on_load_video(self, event):
        # File dialog to load the video
        with wx.FileDialog(self, "Open Video file", wildcard="Video files (*.mp4;*.avi)|*.mp4;*.avi",
                           style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as fileDialog:
            if fileDialog.ShowModal() == wx.ID_CANCEL:
                return

            # Load the chosen file
            pathname = fileDialog.GetPath()
            self.filePathCtrl.SetValue(pathname)
            
            # Load the video with MoviePy
            self.clip = VideoFileClip(pathname)
            wx.MessageBox(f'Video "{os.path.basename(pathname)}" loaded successfully!', 'Info', wx.OK | wx.ICON_INFORMATION)
    
    def on_apply_effects(self, event):
        if not self.clip:
            wx.MessageBox('Please load a video first!', 'Error', wx.OK | wx.ICON_ERROR)
            return
        
        selected_effect = self.effectChoice.GetValue()
        if selected_effect == 'Stutter Loop':
            self.clip = self.apply_stutter_loop(self.clip)
            self.effects_applied.append('Stutter Loop')
        elif selected_effect == 'Pitch Shift':
            self.clip = self.apply_pitch_shift(self.clip)
            self.effects_applied.append('Pitch Shift')
        elif selected_effect == 'Speed Up':
            self.clip = self.clip.fx(vfx.speedx, 2)
            self.effects_applied.append('Speed Up')
        elif selected_effect == 'Slow Down':
            self.clip = self.clip.fx(vfx.speedx, 0.5)
            self.effects_applied.append('Slow Down')
        else:
            wx.MessageBox('Please select an effect!', 'Error', wx.OK | wx.ICON_ERROR)
            return
        
        wx.MessageBox(f'Effect "{selected_effect}" applied successfully!', 'Info', wx.OK | wx.ICON_INFORMATION)
    
    def on_render_video(self, event):
        if not self.clip:
            wx.MessageBox('No video loaded or effects applied!', 'Error', wx.OK | wx.ICON_ERROR)
            return
        
        with wx.FileDialog(self, "Save Video file", wildcard="MP4 files (*.mp4)|*.mp4",
                           style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT) as fileDialog:
            if fileDialog.ShowModal() == wx.ID_CANCEL:
                return

            output_path = fileDialog.GetPath()
            self.clip.write_videofile(output_path)
            wx.MessageBox(f'Video rendered successfully and saved to {output_path}!', 'Info', wx.OK | wx.ICON_INFORMATION)
    
    def apply_stutter_loop(self, clip):
        # Create a stutter loop effect by repeating the first second 3 times
        part = clip.subclip(0, 1)
        return concatenate_videoclips([part, part, part, clip])
    
    def apply_pitch_shift(self, clip):
        # Placeholder for pitch-shifting, using ffmpeg directly
        output_path = "temp_shifted_audio.mp4"
        input_path = clip.filename
        
        (
            ffmpeg
            .input(input_path)
            .filter('asetrate', '44100*1.5')  # Change pitch by 1.5x
            .output(output_path)
            .run()
        )
        
        return VideoFileClip(output_path)

# Run the application
if __name__ == '__main__':
    app = wx.App(False)
    frame = OtoMADApp(None)
    frame.Show()
    app.MainLoop()
