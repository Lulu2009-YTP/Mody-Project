import wx
from moviepy.editor import VideoFileClip, concatenate_videoclips, CompositeVideoClip, TextClip, AudioFileClip
from moviepy.video.fx.all import fadein, fadeout
from moviepy.audio.fx.all import volumex
import os

class CommercialRemixApp(wx.Frame):
    def __init__(self, *args, **kw):
        super(CommercialRemixApp, self).__init__(*args, **kw)
        
        self.InitUI()

    def InitUI(self):
        panel = wx.Panel(self)

        vbox = wx.BoxSizer(wx.VERTICAL)

        # Video Selection
        self.video_path = wx.TextCtrl(panel)
        btn_video = wx.Button(panel, label='Choose Video')
        btn_video.Bind(wx.EVT_BUTTON, self.OnOpenVideo)

        hbox_video = wx.BoxSizer(wx.HORIZONTAL)
        hbox_video.Add(self.video_path, proportion=1, flag=wx.EXPAND)
        hbox_video.Add(btn_video, flag=wx.LEFT, border=5)

        # Audio Selection
        self.audio_path = wx.TextCtrl(panel)
        btn_audio = wx.Button(panel, label='Choose Audio')
        btn_audio.Bind(wx.EVT_BUTTON, self.OnOpenAudio)

        hbox_audio = wx.BoxSizer(wx.HORIZONTAL)
        hbox_audio.Add(self.audio_path, proportion=1, flag=wx.EXPAND)
        hbox_audio.Add(btn_audio, flag=wx.LEFT, border=5)

        # Video Effects
        self.effect_fade_in = wx.CheckBox(panel, label='Fade In Video')
        self.effect_fade_out = wx.CheckBox(panel, label='Fade Out Video')

        # Audio Effects
        self.audio_louder = wx.CheckBox(panel, label='Increase Audio Volume')

        # Process Button
        btn_process = wx.Button(panel, label='Create Commercial Remix')
        btn_process.Bind(wx.EVT_BUTTON, self.OnProcess)

        # Add components to layout
        vbox.Add(hbox_video, flag=wx.EXPAND | wx.ALL, border=10)
        vbox.Add(hbox_audio, flag=wx.EXPAND | wx.ALL, border=10)
        vbox.Add(self.effect_fade_in, flag=wx.ALL, border=10)
        vbox.Add(self.effect_fade_out, flag=wx.ALL, border=10)
        vbox.Add(self.audio_louder, flag=wx.ALL, border=10)
        vbox.Add(btn_process, flag=wx.EXPAND | wx.ALL, border=10)

        panel.SetSizer(vbox)

        self.SetTitle('Commercial Remix Creator')
        self.Centre()

    def OnOpenVideo(self, event):
        with wx.FileDialog(self, "Choose a video file", wildcard="Video files (*.mp4)|*.mp4",
                           style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as fileDialog:
            if fileDialog.ShowModal() == wx.ID_CANCEL:
                return
            self.video_path.SetValue(fileDialog.GetPath())

    def OnOpenAudio(self, event):
        with wx.FileDialog(self, "Choose an audio file", wildcard="Audio files (*.mp3)|*.mp3",
                           style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as fileDialog:
            if fileDialog.ShowModal() == wx.ID_CANCEL:
                return
            self.audio_path.SetValue(fileDialog.GetPath())

    def OnProcess(self, event):
        video_path = self.video_path.GetValue()
        audio_path = self.audio_path.GetValue()

        if not os.path.exists(video_path) or not os.path.exists(audio_path):
            wx.MessageBox('Please select valid video and audio files', 'Error', wx.OK | wx.ICON_ERROR)
            return

        video_clip = VideoFileClip(video_path)
        audio_clip = AudioFileClip(audio_path)

        # Apply audio volume effect if selected
        if self.audio_louder.GetValue():
            audio_clip = volumex(audio_clip, 2.0)  # Increase volume

        video_clip = video_clip.set_audio(audio_clip)

        # Apply video fade-in effect if selected
        if self.effect_fade_in.GetValue():
            video_clip = fadein(video_clip, 2)  # 2 seconds fade in

        # Apply video fade-out effect if selected
        if self.effect_fade_out.GetValue():
            video_clip = fadeout(video_clip, 2)  # 2 seconds fade out

        # Overlaying text (e.g., "2014 Style Commercial Remix")
        text_clip = TextClip("2014 Style Commercial Remix", fontsize=50, color='white')
        text_clip = text_clip.set_position('center').set_duration(5)

        # Combining video with text overlay
        final_clip = CompositeVideoClip([video_clip, text_clip])

        # Saving the final video
        output_path = os.path.splitext(video_path)[0] + "_remix.mp4"
        final_clip.write_videofile(output_path, codec="libx264", audio_codec="aac")

        wx.MessageBox(f'Video saved at {output_path}', 'Success', wx.OK | wx.ICON_INFORMATION)


def main():
    app = wx.App(False)
    frm = CommercialRemixApp(None)
    frm.Show()
    app.MainLoop()

if __name__ == '__main__':
    main()
