import wx
import moviepy.editor as mp
from pydub import AudioSegment
from moviepy.video.fx.all import *
from moviepy.audio.fx.all import *
import random
import os

class VideoRemixApp(wx.Frame):
    def __init__(self, parent, title):
        super(VideoRemixApp, self).__init__(parent, title=title, size=(600, 400))
        
        # Panel and layout
        panel = wx.Panel(self)
        vbox = wx.BoxSizer(wx.VERTICAL)
        
        # Title text
        self.title_text = wx.StaticText(panel, label="2012 Remix Video Generator")
        vbox.Add(self.title_text, flag=wx.ALL | wx.CENTER, border=10)

        # File picker for video
        self.video_picker_label = wx.StaticText(panel, label="Choose video file:")
        vbox.Add(self.video_picker_label, flag=wx.ALL, border=5)
        self.video_picker = wx.FilePickerCtrl(panel, wildcard="Video files (*.mp4;*.avi)|*.mp4;*.avi")
        vbox.Add(self.video_picker, flag=wx.ALL | wx.EXPAND, border=5)
        
        # Add effects options
        self.effects_box_label = wx.StaticText(panel, label="Select Effects:")
        vbox.Add(self.effects_box_label, flag=wx.ALL, border=5)
        
        # Checkbox options for effects
        self.stutter_check = wx.CheckBox(panel, label="Stutter Effect")
        self.reverse_check = wx.CheckBox(panel, label="Reverse Video")
        self.pitch_shift_check = wx.CheckBox(panel, label="Pitch Shift Audio")
        vbox.Add(self.stutter_check, flag=wx.ALL, border=5)
        vbox.Add(self.reverse_check, flag=wx.ALL, border=5)
        vbox.Add(self.pitch_shift_check, flag=wx.ALL, border=5)
        
        # Button to generate the remix
        self.remix_button = wx.Button(panel, label="Generate Remix")
        vbox.Add(self.remix_button, flag=wx.ALL | wx.CENTER, border=10)
        self.remix_button.Bind(wx.EVT_BUTTON, self.on_generate_remix)
        
        # Progress bar
        self.progress_bar = wx.Gauge(panel, range=100)
        vbox.Add(self.progress_bar, flag=wx.ALL | wx.EXPAND, border=5)

        # Set sizer and layout
        panel.SetSizer(vbox)
        self.Centre()
        self.Show()

    def on_generate_remix(self, event):
        # Get video file path
        video_path = self.video_picker.GetPath()
        if not video_path:
            wx.MessageBox("Please select a video file.", "Error", wx.OK | wx.ICON_ERROR)
            return
        
        # Load video using MoviePy
        try:
            clip = mp.VideoFileClip(video_path)
        except Exception as e:
            wx.MessageBox(f"Error loading video: {str(e)}", "Error", wx.OK | wx.ICON_ERROR)
            return

        # Apply effects based on selections
        if self.reverse_check.IsChecked():
            clip = clip.fx(mp.vfx.time_mirror)

        if self.stutter_check.IsChecked():
            clip = self.apply_stutter_effect(clip)

        if self.pitch_shift_check.IsChecked():
            clip = self.apply_pitch_shift(clip)

        # Output remix
        output_path = os.path.splitext(video_path)[0] + "_remix.mp4"
        self.progress_bar.SetValue(50)
        clip.write_videofile(output_path, codec="libx264")
        self.progress_bar.SetValue(100)
        
        wx.MessageBox(f"Remix video saved as {output_path}", "Success", wx.OK | wx.ICON_INFORMATION)
        
    def apply_stutter_effect(self, clip):
        """Applies stutter effect to the video."""
        stutter_times = random.randint(3, 6)
        stuttered_clips = [clip.subclip(0, 0.1)] * stutter_times
        return mp.concatenate_videoclips(stuttered_clips)

    def apply_pitch_shift(self, clip):
        """Applies pitch shift to audio."""
        audio = clip.audio
        # Increase pitch by 1 semitone
        shifted_audio = audio.fx(mp.audio.fx.all.audio_fadein, 2)
        return clip.set_audio(shifted_audio)

if __name__ == "__main__":
    app = wx.App(False)
    frame = VideoRemixApp(None, title="2012 Remix Video Generator")
    app.MainLoop()
