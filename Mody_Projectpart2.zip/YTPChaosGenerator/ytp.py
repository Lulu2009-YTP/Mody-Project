import wx
import random
import moviepy.editor as mp
from moviepy.video.fx import freeze, speedx, mirror_x, mirror_y, rotate

class YTPChaosGenerator(wx.Frame):
    def __init__(self, parent, title):
        super(YTPChaosGenerator, self).__init__(parent, title=title, size=(400, 300))

        panel = wx.Panel(self)

        # Layout for the form
        vbox = wx.BoxSizer(wx.VERTICAL)
        
        self.video_path = None
        
        # Load video button
        self.load_btn = wx.Button(panel, label="Load Video")
        self.load_btn.Bind(wx.EVT_BUTTON, self.on_load_video)
        vbox.Add(self.load_btn, flag=wx.EXPAND|wx.ALL, border=10)

        # Effect options
        self.effects = ['Random Pitch', 'Stutter Loop', 'Mirror Effect', 'Rotate', 'Freeze Frame']
        self.effect_checkboxes = []

        for effect in self.effects:
            checkbox = wx.CheckBox(panel, label=effect)
            vbox.Add(checkbox, flag=wx.EXPAND|wx.ALL, border=5)
            self.effect_checkboxes.append(checkbox)

        # Generate button
        self.generate_btn = wx.Button(panel, label="Generate Chaos Video")
        self.generate_btn.Bind(wx.EVT_BUTTON, self.on_generate)
        vbox.Add(self.generate_btn, flag=wx.EXPAND|wx.ALL, border=10)

        panel.SetSizer(vbox)
        self.Show()

    def on_load_video(self, event):
        with wx.FileDialog(self, "Open Video file", wildcard="Video files (*.mp4;*.avi)|*.mp4;*.avi",
                           style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as fileDialog:
            if fileDialog.ShowModal() == wx.ID_CANCEL:
                return
            self.video_path = fileDialog.GetPath()

    def apply_random_effects(self, clip):
        effects = []
        for i, checkbox in enumerate(self.effect_checkboxes):
            if checkbox.IsChecked():
                effects.append(self.effects[i])

        # Apply selected effects
        if 'Random Pitch' in effects:
            clip = self.random_pitch(clip)
        if 'Stutter Loop' in effects:
            clip = self.stutter_loop(clip)
        if 'Mirror Effect' in effects:
            clip = self.mirror_effect(clip)
        if 'Rotate' in effects:
            clip = self.rotate_video(clip)
        if 'Freeze Frame' in effects:
            clip = self.freeze_frame(clip)
        
        return clip

    def random_pitch(self, clip):
        # Apply a random speed change to simulate pitch shifting
        speed_factor = random.uniform(0.5, 1.5)
        return speedx(clip, factor=speed_factor)

    def stutter_loop(self, clip):
        # Repeat a random section of the clip for a stuttering effect
        start_time = random.uniform(0, clip.duration - 2)
        end_time = start_time + random.uniform(0.1, 0.5)
        subclip = clip.subclip(start_time, end_time)
        return mp.concatenate_videoclips([subclip] * 10)

    def mirror_effect(self, clip):
        # Randomly mirror horizontally or vertically
        if random.choice([True, False]):
            return mirror_x(clip)
        else:
            return mirror_y(clip)

    def rotate_video(self, clip):
        # Rotate the video randomly by -90 to 90 degrees
        angle = random.uniform(-90, 90)
        return rotate(clip, angle)

    def freeze_frame(self, clip):
        # Freeze a random frame for 1-2 seconds
        freeze_time = random.uniform(0, clip.duration)
        return freeze(clip, t=freeze_time, freeze_duration=random.uniform(1, 2))

    def on_generate(self, event):
        if self.video_path is None:
            wx.MessageBox("Please load a video first.", "Error", wx.ICON_ERROR)
            return
        
        # Load the video
        clip = mp.VideoFileClip(self.video_path)

        # Apply random effects
        chaotic_clip = self.apply_random_effects(clip)

        # Output the final video
        output_path = "chaos_video.mp4"
        chaotic_clip.write_videofile(output_path)

        wx.MessageBox(f"Video generated successfully! Saved to {output_path}", "Success", wx.ICON_INFORMATION)


if __name__ == '__main__':
    app = wx.App()
    frame = YTPChaosGenerator(None, title="YTP Chaos Video Generator")
    app.MainLoop()
