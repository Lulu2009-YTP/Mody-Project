from moviepy.editor import VideoFileClip

def apply_effects(video_path, effect):
    video = VideoFileClip(video_path)
    
    if effect == 'zoom':
        video = video.fx(vfx.zoom_in, factor=1.5)
    elif effect == 'glitch':
        # Add glitch effect logic
        pass
    elif effect == 'reverse':
        video = video.fx(vfx.time_mirror)
    elif effect == 'pitch_shift':
        # Add pitch shift effect
        pass

    # Save output to the media/output/ folder
    video.write_videofile(f"media/output/{effect}_output.mp4")
