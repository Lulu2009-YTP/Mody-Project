import tkinter as tk
from tkinter import filedialog

def create_form():
    root = tk.Tk()
    root.title("YTP Poopism Chaos Generator")

    def open_file():
        file_path = filedialog.askopenfilename()
        # Add logic to handle file selection

    # Create a button to select input video
    input_button = tk.Button(root, text="Select Input Video", command=open_file)
    input_button.pack(pady=10)

    # Add more form elements as needed for chaos settings, output options, etc.

    return root
