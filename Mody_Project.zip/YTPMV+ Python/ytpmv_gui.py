import os
import tkinter as tk
from tkinter import filedialog, messagebox
from moviepy.editor import VideoFileClip, concatenate_videoclips
from pydub import AudioSegment
import threading

class YTPMVApp(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("YTPMV+")
        self.geometry("400x300")

        # Input Folder
        self.input_folder = os.path.join(os.getcwd(), "input")
        self.output_folder = os.path.join(os.getcwd(), "output")
        self.temp_folder = os.path.join(os.getcwd(), "temp")
        self.create_folders()

        # GUI Elements
        self.create_widgets()

    def create_widgets(self):
        # Browse Video Button
        self.browse_video_btn = tk.Button(self, text="Browse Video", command=self.browse_video)
        self.browse_video_btn.pack(pady=10)

        # Browse Audio Button
        self.browse_audio_btn = tk.Button(self, text="Browse Audio", command=self.browse_audio)
        self.browse_audio_btn.pack(pady=10)

        # Start Processing Button
        self.start_btn = tk.Button(self, text="Start Processing", command=self.start_processing)
        self.start_btn.pack(pady=20)

        # Progress label
        self.progress_label = tk.Label(self, text="")
        self.progress_label.pack(pady=10)

    def create_folders(self):
        """Creates necessary folders if they don't exist."""
        os.makedirs(self.input_folder, exist_ok=True)
        os.makedirs(self.output_folder, exist_ok=True)
        os.makedirs(self.temp_folder, exist_ok=True)

    def browse_video(self):
        self.video_file = filedialog.askopenfilename(initialdir=self.input_folder, title="Select Video File",
                                                     filetypes=(("MP4 files", "*.mp4"), ("All files", "*.*")))
        if self.video_file:
            messagebox.showinfo("Selected Video", f"Selected Video: {os.path.basename(self.video_file)}")

    def browse_audio(self):
        self.audio_file = filedialog.askopenfilename(initialdir=self.input_folder, title="Select Audio File",
                                                     filetypes=(("MP3 files", "*.mp3"), ("All files", "*.*")))
        if self.audio_file:
            messagebox.showinfo("Selected Audio", f"Selected Audio: {os.path.basename(self.audio_file)}")

    def process_video_audio(self):
        """Processes video and audio files."""
        try:
            # Load video
            self.progress_label.config(text="Loading video...")
            video_clip = VideoFileClip(self.video_file)

            # Load audio
            self.progress_label.config(text="Loading audio...")
            audio_clip = AudioSegment.from_file(self.audio_file)

            # Replace video's audio with new audio
            self.progress_label.config(text="Replacing audio...")
            video_with_new_audio = video_clip.set_audio(audio_clip)

            # Output file
            output_path = os.path.join(self.output_folder, "ytpmv_output.mp4")
            self.progress_label.config(text="Exporting video...")
            video_with_new_audio.write_videofile(output_path, codec="libx264")

            self.progress_label.config(text="Processing complete!")
            messagebox.showinfo("Success", "YTPMV Video Created Successfully!")

        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def start_processing(self):
        """Starts the video/audio processing on a separate thread."""
        threading.Thread(target=self.process_video_audio).start()

if __name__ == "__main__":
    app = YTPMVApp()
    app.mainloop()
