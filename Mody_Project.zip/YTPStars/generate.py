import moviepy.editor as mpe
import tkinter as tk
from tkinter import ttk
from tkinter import filedialog

def open_video():
    global video_clip
    filepath = filedialog.askopenfilename(
        initialdir="/",
        title="Select a Video",
        filetypes=(("video files", "*.mp4;*.avi"), ("all files", "*.*"))
    )
    if filepath:
        video_clip = mpe.VideoFileClip(filepath)
        video_label.config(text=f"Selected Video: {filepath}")

def save_video():
    if video_clip is None:
        return
    save_path = filedialog.asksaveasfilename(
        defaultextension=".mp4", 
        filetypes=(("MP4 files", "*.mp4"), ("AVI files", "*.avi"))
    )
    if save_path:
        video_clip.write_videofile(save_path)

def apply_effects():
    if video_clip is None:
        return

    # Sample Effect: Slow Down
    # You can add more effects here
    speed = float(speed_slider.get())
    video_clip = video_clip.fx(mpe.vfx.speedx, speed)
    video_label.config(text="Effects Applied!")

def main():
    global video_clip, video_label, speed_slider

    window = tk.Tk()
    window.title("Simple Video Editor")

    open_button = tk.Button(window, text="Open Video", command=open_video)
    open_button.pack()

    video_label = tk.Label(window, text="No Video Selected")
    video_label.pack()

    # Speed Adjustment
    speed_label = tk.Label(window, text="Speed:")
    speed_label.pack()
    speed_slider = ttk.Scale(window, from_=0.1, to=2.0, orient=tk.HORIZONTAL)
    speed_slider.pack()

    apply_button = tk.Button(window, text="Apply Effects", command=apply_effects)
    apply_button.pack()

    save_button = tk.Button(window, text="Save Video", command=save_video)
    save_button.pack()

    window.mainloop()

if __name__ == "__main__":
    main()