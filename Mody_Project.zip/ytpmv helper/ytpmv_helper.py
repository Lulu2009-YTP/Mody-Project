import tkinter as tk
from tkinter import filedialog
import moviepy.editor as mp
from tracker import Tracker
from effects import apply_effects

class YTPMVHelperApp:
    def __init__(self, root):
        self.root = root
        self.root.title("YTPMV Helper")
        
        # Input Video Button
        self.video_label = tk.Label(root, text="Select Video File:")
        self.video_label.pack(pady=5)
        self.video_btn = tk.Button(root, text="Browse", command=self.browse_video)
        self.video_btn.pack(pady=5)
        
        # Input Audio Button
        self.audio_label = tk.Label(root, text="Select Audio File:")
        self.audio_label.pack(pady=5)
        self.audio_btn = tk.Button(root, text="Browse", command=self.browse_audio)
        self.audio_btn.pack(pady=5)
        
        # Apply Effects Button
        self.effects_btn = tk.Button(root, text="Apply Effects", command=self.apply_effects)
        self.effects_btn.pack(pady=5)
        
        # Output Video Button
        self.output_label = tk.Label(root, text="Save Output As:")
        self.output_label.pack(pady=5)
        self.output_btn = tk.Button(root, text="Save", command=self.save_output)
        self.output_btn.pack(pady=5)

    def browse_video(self):
        self.video_path = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4;*.avi")])
    
    def browse_audio(self):
        self.audio_path = filedialog.askopenfilename(filetypes=[("Audio files", "*.mp3;*.wav")])
    
    def apply_effects(self):
        tracker = Tracker(self.video_path, self.audio_path)
        video = mp.VideoFileClip(self.video_path)
        audio = mp.AudioFileClip(self.audio_path)
        
        # Generate the YTPMV with tracking and effects
        video_with_effects = apply_effects(video, audio, tracker)
        self.output_video = video_with_effects
    
    def save_output(self):
        output_path = filedialog.asksaveasfilename(defaultextension=".mp4")
        self.output_video.write_videofile(output_path, codec="libx264")
        
if __name__ == "__main__":
    root = tk.Tk()
    app = YTPMVHelperApp(root)
    root.mainloop()
