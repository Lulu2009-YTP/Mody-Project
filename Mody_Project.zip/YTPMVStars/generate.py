import tkinter as tk
from tkinter import ttk
from tkinter import filedialog
from moviepy.editor import VideoFileClip, AudioFileClip
import moviepy.editor as mpe
import os

class YTPMV_GUI:
    def __init__(self, master):
        self.master = master
        master.title("YTPMV+")

        # Menu bar
        menubar = tk.Menu(master)
        filemenu = tk.Menu(menubar, tearoff=0)
        filemenu.add_command(label="Open", command=self.open_file)
        filemenu.add_separator()
        filemenu.add_command(label="Exit", command=master.quit)
        menubar.add_cascade(label="File", menu=filemenu)
        master.config(menu=menubar)

        # Frames
        self.source_frame = tk.Frame(master)
        self.source_frame.pack(side=tk.LEFT, padx=10, pady=10)

        self.plugins_frame = tk.Frame(master)
        self.plugins_frame.pack(side=tk.LEFT, padx=10, pady=10)

        self.controls_frame = tk.Frame(master)
        self.controls_frame.pack(side=tk.LEFT, padx=10, pady=10)

        # Source frame
        self.source_label = tk.Label(self.source_frame, text="Browse Sources:")
        self.source_label.pack()

        self.source_listbox = tk.Listbox(self.source_frame, width=30, height=5, selectmode=tk.SINGLE)
        self.source_listbox.pack()

        self.browse_button = tk.Button(self.source_frame, text="Browse", command=self.browse_source)
        self.browse_button.pack()

        self.audio_label = tk.Label(self.source_frame, text="Browse Audio:")
        self.audio_label.pack()

        self.audio_listbox = tk.Listbox(self.source_frame, width=30, height=5, selectmode=tk.SINGLE)
        self.audio_listbox.pack()

        self.browse_audio_button = tk.Button(self.source_frame, text="Browse", command=self.browse_audio)
        self.browse_audio_button.pack()

        self.ok_button = tk.Button(self.source_frame, text="OK", command=self.process_file)
        self.ok_button.pack()

        self.cancel_button = tk.Button(self.source_frame, text="Cancel", command=master.quit)
        self.cancel_button.pack()

        # Plugins frame
        self.plugins_label = tk.Label(self.plugins_frame, text="Selected Plugins:")
        self.plugins_label.pack()

        self.plugins_listbox = tk.Listbox(self.plugins_frame, width=20, height=5, selectmode=tk.MULTIPLE)
        self.plugins_listbox.pack()

        self.cookie_cutter_var = tk.BooleanVar(value=False)
        self.cookie_cutter_check = tk.Checkbutton(self.plugins_frame, text="Cookie Cutter", variable=self.cookie_cutter_var)
        self.cookie_cutter_check.pack()

        self.checkerboard_var = tk.BooleanVar(value=True)
        self.checkerboard_check = tk.Checkbutton(self.plugins_frame, text="Checkerboard", variable=self.checkerboard_var)
        self.checkerboard_check.pack()

        self.cube_var = tk.BooleanVar(value=False)
        self.cube_check = tk.Checkbutton(self.plugins_frame, text="3D Cube", variable=self.cube_var)
        self.cube_check.pack()

        self.screen_flip_var = tk.BooleanVar(value=False)
        self.screen_flip_check = tk.Checkbutton(self.plugins_frame, text="Automatic Screen Flip", variable=self.screen_flip_var)
        self.screen_flip_check.pack()

        self.chroma_key_var = tk.BooleanVar(value=False)
        self.chroma_key_check = tk.Checkbutton(self.plugins_frame, text="Chroma Key", variable=self.chroma_key_var)
        self.chroma_key_check.pack()

        self.cc_cylinder_var = tk.BooleanVar(value=False)
        self.cc_cylinder_check = tk.Checkbutton(self.plugins_frame, text="CC Cylinder", variable=self.cc_cylinder_var)
        self.cc_cylinder_check.pack()

        # Controls frame
        self.pitch_helper_label = tk.Label(self.controls_frame, text="Pitch Helper:")
        self.pitch_helper_label.pack()

        self.pitch_helper_scale = tk.Scale(self.controls_frame, from_=0, to=100, orient=tk.HORIZONTAL, command=self.update_pitch)
        self.pitch_helper_scale.pack()

        self.equalizer_label = tk.Label(self.controls_frame, text="Equalizer:")
        self.equalizer_label.pack()

        self.equalizer_scale = tk.Scale(self.controls_frame, from_=0, to=100, orient=tk.HORIZONTAL, command=self.update_equalizer)
        self.equalizer_scale.pack()

        self.progress_bar = ttk.Progressbar(self.controls_frame, orient="horizontal", mode="determinate", length=200)
        self.progress_bar.pack()

        self.status_label = tk.Label(self.controls_frame, text="Now Generating...")
        self.status_label.pack()

    def open_file(self):
        filename = filedialog.askopenfilename(initialdir="/", title="Select a File", filetypes=(("Video files", "*.mp4;*.avi"), ("all files", "*.*")))
        if filename:
            self.source_listbox.delete(0, tk.END)
            self.source_listbox.insert(tk.END, filename)

    def browse_source(self):
        filename = filedialog.askopenfilename(initialdir="/", title="Select a File", filetypes=(("Video files", "*.mp4;*.avi"), ("all files", "*.*")))
        if filename:
            self.source_listbox.delete(0, tk.END)
            self.source_listbox.insert(tk.END, filename)

    def browse_audio(self):
        filename = filedialog.askopenfilename(initialdir="/", title="Select a File", filetypes=(("Audio files", "*.mp3;*.wav"), ("all files", "*.*")))
        if filename:
            self.audio_listbox.delete(0, tk.END)
            self.audio_listbox.insert(tk.END, filename)

    def process_file(self):
        source_file = self.source_listbox.get(tk.ANCHOR)
        audio_file = self.audio_listbox.get(tk.ANCHOR)

        # Check if source and audio files are selected
        if not source_file or not audio_file:
            tk.messagebox.showerror("Error", "Please select both source and audio files.")
            return

        # Get selected plugins
        plugins = []
        if self.cookie_cutter_var.get():
            plugins.append("cookie_cutter")
        if self.checkerboard_var.get():
            plugins.append("checkerboard")
        if self.cube_var.get():
            plugins.append("cube")
        if self.screen_flip_var.get():
            plugins.append("screen_flip")
        if self.chroma_key_var.get():
            plugins.append("chroma_key")
        if self.cc_cylinder_var.get():
            plugins.append("cc_cylinder")

        # Load video and audio
        video = VideoFileClip(source_file)
        audio = AudioFileClip(audio_file)

        # Apply plugins
        for plugin in plugins:
            if plugin == "cookie_cutter":
                video = video.fx(mpe.vfx.colorx, 0.5)  # Adjust the color value as needed
            elif plugin == "checkerboard":
                video = video.fx(mpe.vfx.checkerboard, 20)  # Adjust the size as needed
            elif plugin == "cube":
                video = video.fx(mpe.vfx.cube, 10)  # Adjust the size as needed
            elif plugin == "screen_flip":
                video = video.fx(mpe.vfx.mirror_x)
            elif plugin == "chroma_key":
                video = video.fx(mpe.vfx.color_key, color=(255, 0, 0), tolerance=10)  # Replace with the desired color
            elif plugin == "cc_cylinder":
                video = video.fx(mpe.vfx.cc_cylinder, 100)  # Adjust the radius as needed

        # Set audio for the video
        video.audio = audio

        # Apply pitch and equalizer adjustments
        pitch_value = self.pitch_helper_scale.get()
        equalizer_value = self.equalizer_scale.get()
        video.audio = video.audio.fx(mpe.afx.audio_normalize)  # Normalize audio first
        video.audio = video.audio.fx(mpe.afx.audio_fadein, 1)  # Fade in audio for a smoother transition
        video.audio = video.audio.fx(mpe.afx.audio_fadeout, 1)  # Fade out audio for a smoother transition
        video.audio = video.audio.fx(mpe.afx.audio_pitch_change, pitch_value / 50)  # Adjust pitch value as needed
        video.audio = video.audio.fx(mpe.afx.audio_equalizer, equalizer_value / 50)  # Adjust equalizer value as needed

        # Set progress bar values
        self.progress_bar["maximum"] = 100
        self.progress_bar["value"] = 0
        self.status_label.config(text="Now Generating...")

        # Export video
        output_file = os.path.splitext(source_file)[0] + "_ytpmv.mp4"
        video.write_videofile(output_file, codec="libx264", progress_bar=True, logger=None, preset="medium", threads=8, fps=video.fps, audio_bitrate="192k", audio_codec="aac")

        self.status_label.config(text="Generation Complete!")
        self.progress_bar["value"] = 100

    def update_pitch(self, value):
        # Placeholder for future implementation of real-time pitch preview
        pass

    def update_equalizer(self, value):
        # Placeholder for future implementation of real-time equalizer preview
        pass

root = tk.Tk()
app = YTPMV_GUI(root)
root.mainloop()