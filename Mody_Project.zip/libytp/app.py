import wx
import os
from ytp_effects import stutter_effect, zoom_in_effect, pitch_shift
import moviepy.editor as mp

class YTPForm(wx.Frame):
    def __init__(self, parent, title):
        super(YTPForm, self).__init__(parent, title=title, size=(400, 300))
        
        panel = wx.Panel(self)
        sizer = wx.BoxSizer(wx.VERTICAL)
        
        self.video_path = wx.TextCtrl(panel)
        browse_button = wx.Button(panel, label="Browse Video")
        apply_effects_button = wx.Button(panel, label="Apply Effects")
        
        sizer.Add(self.video_path, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(browse_button, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(apply_effects_button, 0, wx.EXPAND | wx.ALL, 5)
        
        panel.SetSizer(sizer)
        
        self.Bind(wx.EVT_BUTTON, self.on_browse, browse_button)
        self.Bind(wx.EVT_BUTTON, self.on_apply_effects, apply_effects_button)
    
    def on_browse(self, event):
        dialog = wx.FileDialog(self, "Choose a video file", wildcard="Video files (*.mp4)|*.mp4", style=wx.FD_OPEN)
        if dialog.ShowModal() == wx.ID_OK:
            self.video_path.SetValue(dialog.GetPath())
        dialog.Destroy()
    
    def on_apply_effects(self, event):
        video_file = self.video_path.GetValue()
        if os.path.exists(video_file):
            video = mp.VideoFileClip(video_file)
            video = stutter_effect(video)
            video = zoom_in_effect(video)
            video.audio = pitch_shift(video.audio)
            
            video.write_videofile("output_ytp.mp4")
            wx.MessageBox("Effects applied!", "Info", wx.OK | wx.ICON_INFORMATION)

if __name__ == '__main__':
    app = wx.App(False)
    frame = YTPForm(None, "Super YTP Poopism Generator")
    frame.Show()
    app.MainLoop()
