import tkinter as tk
from tkinter import filedialog
from moviepy.editor import VideoFileClip, AudioFileClip, concatenate_videoclips
import os

# Main Application class
class YTPApp:
    def __init__(self, root):
        self.root = root
        self.root.title("YTP Editor")
        self.root.geometry("500x300")

        # Labels and Buttons
        tk.Label(root, text="YouTube Poop Editor").pack(pady=10)

        # Browse Source Button
        self.source_btn = tk.Button(root, text="Browse Source Video", command=self.browse_source)
        self.source_btn.pack(pady=5)

        # Browse Audio Button
        self.audio_btn = tk.Button(root, text="Browse Audio", command=self.browse_audio)
        self.audio_btn.pack(pady=5)

        # Browse Image Button
        self.image_btn = tk.Button(root, text="Browse Image", command=self.browse_image)
        self.image_btn.pack(pady=5)

        # Style Selection
        tk.Label(root, text="Select YTP Style:").pack(pady=10)
        self.style_var = tk.StringVar(value="ytp_2012")
        styles = ["ytp_2010", "ytp_2012", "ytp_2021", "poopism", "chaos", "automatic_ytp"]
        for style in styles:
            tk.Radiobutton(root, text=style.replace('_', ' ').title(), variable=self.style_var, value=style).pack()

        # Apply Button
        self.apply_btn = tk.Button(root, text="Apply Style", command=self.apply_style)
        self.apply_btn.pack(pady=10)

    # Browse source video
    def browse_source(self):
        self.source_path = filedialog.askopenfilename(filetypes=[("Video Files", "*.mp4;*.avi")])
        print(f"Selected source video: {self.source_path}")

    # Browse audio
    def browse_audio(self):
        self.audio_path = filedialog.askopenfilename(filetypes=[("Audio Files", "*.mp3;*.wav")])
        print(f"Selected audio file: {self.audio_path}")

    # Browse image
    def browse_image(self):
        self.image_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg")])
        print(f"Selected image file: {self.image_path}")

    # Apply YTP style based on the selected radio button
    def apply_style(self):
        selected_style = self.style_var.get()
        print(f"Applying style: {selected_style}")
        if hasattr(self, 'source_path'):
            clip = VideoFileClip(self.source_path)
            if selected_style == 'ytp_2010':
                self.ytp_2010_effect(clip)
            elif selected_style == 'ytp_2012':
                self.ytp_2012_effect(clip)
            # Add more styles and effects as needed

    # Placeholder effect for 2010 YTP style
    def ytp_2010_effect(self, clip):
        print("Applying YTP 2010-style effects...")
        clip = clip.fx(vfx.mirror_x)
        output = os.path.join(os.getcwd(), "ytp_2010_output.mp4")
        clip.write_videofile(output)
        print(f"Saved as {output}")

    # Placeholder effect for 2012 YTP style
    def ytp_2012_effect(self, clip):
        print("Applying YTP 2012-style effects...")
        # Implement more complex logic here for 2012 effects
        output = os.path.join(os.getcwd(), "ytp_2012_output.mp4")
        clip.write_videofile(output)
        print(f"Saved as {output}")

if __name__ == "__main__":
    root = tk.Tk()
    app = YTPApp(root)
    root.mainloop()
