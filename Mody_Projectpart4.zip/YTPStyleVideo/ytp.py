import random
from moviepy.editor import *
from moviepy.video.fx.all import *

# List of sample video clips (replace with your own)
video_clips = [
    "clip1.mp4",
    "clip2.mp4",
    "clip3.mp4",
    "clip4.mp4",
    "clip5.mp4",
]

# List of sample audio clips (replace with your own)
audio_clips = [
    "audio1.mp3",
    "audio2.mp3",
    "audio3.mp3",
]

# List of sample images (replace with your own)
images = [
    "image1.jpg",
    "image2.jpg",
    "image3.jpg",
]

def create_chaotic_clip(clip, duration):
    effects = [
        lambda c: c.fx(vfx.colorx, factor=random.uniform(0.5, 2.0)),
        lambda c: c.fx(vfx.mirror_x),
        lambda c: c.fx(vfx.mirror_y),
        lambda c: c.fx(vfx.invert_colors),
        lambda c: c.fx(vfx.speedx, factor=random.uniform(0.5, 2.0)),
    ]
    
    effect = random.choice(effects)
    return effect(clip).set_duration(duration)

def create_ytp():
    final_duration = 60  # Total duration of the YTP video
    clips = []
    
    while sum([c.duration for c in clips]) < final_duration:
        clip_type = random.choice(["video", "audio", "image", "text"])
        
        if clip_type == "video":
            video = VideoFileClip(random.choice(video_clips))
            duration = random.uniform(0.5, 3)
            clip = create_chaotic_clip(video.subclip(0, duration), duration)
        
        elif clip_type == "audio":
            audio = AudioFileClip(random.choice(audio_clips))
            duration = random.uniform(1, 5)
            clip = ColorClip(size=(1280, 720), color=(random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)))
            clip = clip.set_duration(duration).set_audio(audio.subclip(0, duration))
        
        elif clip_type == "image":
            img = ImageClip(random.choice(images))
            duration = random.uniform(0.2, 1)
            clip = create_chaotic_clip(img, duration)
        
        else:  # text
            txt = TextClip(random.choice(["POOP", "YTP", "CHAOS", "LOL", "WTF"]), fontsize=100, color='white', font='Arial')
            duration = random.uniform(0.2, 1)
            clip = create_chaotic_clip(txt, duration)
        
        clips.append(clip)
    
    final_clip = concatenate_videoclips(clips)
    
    # Add a chaotic soundtrack
    soundtrack = AudioFileClip(random.choice(audio_clips)).subclip(0, final_duration)
    final_clip = final_clip.set_audio(soundtrack)
    
    return final_clip

# Generate and export the YTP video
ytp_video = create_ytp()
ytp_video.write_videofile("chaotic_ytp.mp4", fps=30)
