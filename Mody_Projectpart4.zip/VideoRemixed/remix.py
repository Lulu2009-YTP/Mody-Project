import tkinter as tk
from tkinter import filedialog, messagebox
from moviepy.editor import *
from moviepy.video.fx.all import resize, crop
import random
import os

class VideoRemixCreator:
    def __init__(self, master):
        self.master = master
        master.title("Video Remix Songs - Covers Mix Creator")

        self.clips = []
        self.audio_tracks = []

        # GUI elements
        self.add_video_button = tk.Button(master, text="Add Video Clip", command=self.add_video)
        self.add_video_button.pack()

        self.add_audio_button = tk.Button(master, text="Add Audio Track", command=self.add_audio)
        self.add_audio_button.pack()

        self.create_button = tk.Button(master, text="Create Remix", command=self.create_remix)
        self.create_button.pack()

        self.clip_listbox = tk.Listbox(master)
        self.clip_listbox.pack()

        self.audio_listbox = tk.Listbox(master)
        self.audio_listbox.pack()

    def add_video(self):
        file = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4 *.avi *.mov")])
        if file:
            self.clips.append(file)
            self.clip_listbox.insert(tk.END, os.path.basename(file))

    def add_audio(self):
        file = filedialog.askopenfilename(filetypes=[("Audio files", "*.mp3 *.wav")])
        if file:
            self.audio_tracks.append(file)
            self.audio_listbox.insert(tk.END, os.path.basename(file))

    def create_remix(self):
        if not self.clips or not self.audio_tracks:
            messagebox.showerror("Error", "Please add at least one video clip and one audio track.")
            return

        # Load video clips
        video_clips = [VideoFileClip(clip) for clip in self.clips]

        # Resize and crop clips to a standard size
        target_size = (1920, 1080)
        processed_clips = []
        for clip in video_clips:
            resized = resize(clip, height=target_size[1])
            if resized.w > target_size[0]:
                resized = crop(resized, width=target_size[0], height=target_size[1], x_center=resized.w/2, y_center=resized.h/2)
            else:
                resized = resize(resized, width=target_size[0])
            processed_clips.append(resized)

        # Add transitions
        final_clips = []
        for i, clip in enumerate(processed_clips):
            if i > 0:
                transition = CrossFadeTransition(processed_clips[i-1], clip, 1)
                final_clips.append(transition)
            final_clips.append(clip)

        # Concatenate video clips
        final_video = concatenate_videoclips(final_clips)

        # Load and concatenate audio tracks
        audio_clips = [AudioFileClip(track) for track in self.audio_tracks]
        final_audio = concatenate_audioclips(audio_clips)

        # Set the audio of the final video
        final_video = final_video.set_audio(final_audio)

        # Add text overlays
        txt_clip = TextClip("Video Remix", fontsize=70, color='white', font='Arial')
        txt_clip = txt_clip.set_pos('center').set_duration(5)

        final_video = CompositeVideoClip([final_video, txt_clip])

        # Write the result to a file
        output_file = filedialog.asksaveasfilename(defaultextension=".mp4")
        final_video.write_videofile(output_file, codec='libx264', audio_codec='aac')

        messagebox.showinfo("Success", "Remix video created successfully!")

root = tk.Tk()
creator = VideoRemixCreator(root)
root.mainloop()
