from moviepy.editor import *
import random

# Load video source
source = VideoFileClip("source.mp4")

# Function to create chaotic effects for YTP
def chaotic_style(clip, intensity=10):
    clips = []
    duration = clip.duration
    # Split the clip into random segments and apply effects
    for i in range(intensity):
        start = random.uniform(0, duration - 1)
        end = min(start + random.uniform(0.1, 1), duration)
        subclip = clip.subclip(start, end)
        
        # Apply random effects to the subclip (speed up, reverse, color effects)
        if random.choice([True, False]):
            subclip = subclip.fx(vfx.speedx, random.uniform(1.5, 4))  # Speed up
        if random.choice([True, False]):
            subclip = subclip.fx(vfx.time_mirror)  # Reverse
            
        # Apply visual effects
        if random.choice([True, False]):
            subclip = subclip.fx(vfx.lum_contrast, contrast=random.uniform(0.5, 2.5))
        
        # Add glitchy or meme-y sound effects (optional)
        # audio_clip = AudioFileClip("sound.mp3").subclip(0, subclip.duration)
        # subclip = subclip.set_audio(audio_clip)

        clips.append(subclip)
    
    return concatenate_videoclips(clips)

# Apply chaotic-style YTP
ytp_chaos = chaotic_style(source, intensity=20)

# Save the output video
ytp_chaos.write_videofile("ytp_chaos_style.mp4", codec="libx264")

# Function for simulating 2000s YTP Style (Repetition & Stutter)
def ytp_2000s_style(clip):
    clips = []
    for i in range(10):
        subclip = clip.subclip(i, i + 2)  # Reuse short clips
        subclip = subclip.fx(vfx.speedx, 0.5)  # Slow down some clips
        clips.append(subclip)
        clips.append(subclip.fx(vfx.time_mirror))  # Reverse clips
    return concatenate_videoclips(clips)

# Apply the 2000s YTP style
ytp_2000s = ytp_2000s_style(source)
ytp_2000s.write_videofile("ytp_2000s_style.mp4", codec="libx264")

# Function for 2010s-style (More polished with memetic editing)
def ytp_2010s_style(clip):
    clips = []
    for i in range(10):
        subclip = clip.subclip(i, i + 2)  # Meme editing, freeze frames, color keying
        if random.choice([True, False]):
            subclip = subclip.fx(vfx.colorx, 0.5)  # Lower saturation
        if random.choice([True, False]):
            subclip = subclip.fx(vfx.mirror_x)  # Mirror effect
        clips.append(subclip)
    return concatenate_videoclips(clips)

# Apply 2010s YTP style
ytp_2010s = ytp_2010s_style(source)
ytp_2010s.write_videofile("ytp_2010s_style.mp4", codec="libx264")

# Function for 2020s YTP style (modern memetic overload, hyper-saturated)
def ytp_2020s_style(clip):
    clips = []
    for i in range(10):
        subclip = clip.subclip(i, i + 2)  # Quick cuts, meme overlays, heavy contrast
        subclip = subclip.fx(vfx.lum_contrast, contrast=2, brightness=1)  # High contrast
        subclip = subclip.fx(vfx.colorx, 2)  # Over-saturate
        clips.append(subclip)
    return concatenate_videoclips(clips)

# Apply 2020s YTP style
ytp_2020s = ytp_2020s_style(source)
ytp_2020s.write_videofile("ytp_2020s_style.mp4", codec="libx264")

# Generate Movie with Specific Style
def create_ytp_style(style, video_file):
    if style == "chaos":
        return chaotic_style(video_file)
    elif style == "2000s":
        return ytp_2000s_style(video_file)
    elif style == "2010s":
        return ytp_2010s_style(video_file)
    elif style == "2020s":
        return ytp_2020s_style(video_file)
    else:
        raise ValueError("Style not supported.")

# Example usage:
# video_file = VideoFileClip("your_video.mp4")
# create_ytp_style("chaos", video_file).write_videofile("output.mp4", codec="libx264")
