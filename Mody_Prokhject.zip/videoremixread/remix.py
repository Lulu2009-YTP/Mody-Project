import tkinter as tk
from tkinter import filedialog, messagebox
from moviepy.editor import VideoFileClip, AudioFileClip, ImageClip, concatenate_videoclips

class VideoRemixApp:
    def __init__(self, master):
        self.master = master
        master.title("Video Remix App")

        self.video_paths = []
        self.audio_path = ""
        self.image_path = ""

        self.label = tk.Label(master, text="Video Remix Application")
        self.label.pack()

        self.browse_video_button = tk.Button(master, text="Add Browse Source Video", command=self.browse_video)
        self.browse_video_button.pack()

        self.browse_audio_button = tk.Button(master, text="Add Browse Audio", command=self.browse_audio)
        self.browse_audio_button.pack()

        self.browse_image_button = tk.Button(master, text="Add Browse Image", command=self.browse_image)
        self.browse_image_button.pack()

        self.remix_button = tk.Button(master, text="Remix Videos", command=self.remix_videos)
        self.remix_button.pack()

    def browse_video(self):
        file_path = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4;*.avi;*.mov")])
        if file_path:
            self.video_paths.append(file_path)
            messagebox.showinfo("Selected Video", f"Added: {file_path}")

    def browse_audio(self):
        file_path = filedialog.askopenfilename(filetypes=[("Audio files", "*.mp3;*.wav")])
        if file_path:
            self.audio_path = file_path
            messagebox.showinfo("Selected Audio", f"Added: {file_path}")

    def browse_image(self):
        file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.jpg;*.png")])
        if file_path:
            self.image_path = file_path
            messagebox.showinfo("Selected Image", f"Added: {file_path}")

    def remix_videos(self):
        if not self.video_paths:
            messagebox.showwarning("No Videos", "Please add at least one video source.")
            return
        
        clips = [VideoFileClip(path) for path in self.video_paths]

        # Optionally add an image as a clip if provided
        if self.image_path:
            img_clip = ImageClip(self.image_path).set_duration(2)  # 2 seconds duration
            clips.append(img_clip)

        final_clip = concatenate_videoclips(clips)

        # Add audio if provided
        if self.audio_path:
            audio_clip = AudioFileClip(self.audio_path)
            final_clip = final_clip.set_audio(audio_clip)

        output_file = "remixed_video.mp4"
        final_clip.write_videofile(output_file)
        messagebox.showinfo("Success", f"Remixed video created: {output_file}")

if __name__ == "__main__":
    root = tk.Tk()
    app = VideoRemixApp(root)
    root.mainloop()
