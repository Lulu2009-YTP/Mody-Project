from moviepy.editor import VideoFileClip, concatenate_videoclips, AudioFileClip
from pydub import AudioSegment
import os

# Function to load and concatenate audio files
def load_and_mix_audio(audio_files):
    combined = AudioSegment.silent(duration=0)  # Start with a silent track
    for file in audio_files:
        audio = AudioSegment.from_file(file)
        combined = combined + audio  # Concatenate the audio files
    return combined

# Function to overlay audio onto video clips and concatenate the videos
def create_video_mix(video_files, mixed_audio, output_file='output_video.mp4'):
    video_clips = []
    
    # Iterate over the video files and assign the mixed audio to them
    for i, video_file in enumerate(video_files):
        video_clip = VideoFileClip(video_file)
        if i == 0:  # Use the mixed audio only for the first clip
            audio_file = "temp_audio.mp3"
            mixed_audio.export(audio_file, format="mp3")
            audio_clip = AudioFileClip(audio_file)
            video_clip = video_clip.set_audio(audio_clip)
        video_clips.append(video_clip)

    # Concatenate video clips into a single video
    final_video = concatenate_videoclips(video_clips, method="compose")
    
    # Export the final video
    final_video.write_videofile(output_file, codec="libx264")

# Define paths for audio and video files
audio_files = ["audio1.mp3", "audio2.mp3", "audio3.mp3"]  # Replace with your audio file paths
video_files = ["video1.mp4", "video2.mp4", "video3.mp4"]  # Replace with your video file paths

# Load and mix audio
mixed_audio = load_and_mix_audio(audio_files)

# Create the final video remix with covers
create_video_mix(video_files, mixed_audio)
