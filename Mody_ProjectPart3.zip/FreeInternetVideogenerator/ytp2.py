import cv2
import numpy as np
import random
import os

def create_ytp_video(input_video_path, output_video_path, num_effects=10):
    cap = cv2.VideoCapture(input_video_path)
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_video_path, fourcc, fps, (width, height))

    effects = [apply_random_effect] * num_effects

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        for effect in effects:
            frame = effect(frame)

        out.write(frame)

    cap.release()
    out.release()

def apply_random_effect(frame):
    effect_type = random.choice(['invert', 'blur', 'shatter', 'pixelate'])
    if effect_type == 'invert':
        return cv2.bitwise_not(frame)
    elif effect_type == 'blur':
        return cv2.GaussianBlur(frame, (15, 15), 0)
    elif effect_type == 'shatter':
        return shatter_effect(frame)
    elif effect_type == 'pixelate':
        return pixelate_effect(frame)
    return frame

def shatter_effect(frame):
    height, width, _ = frame.shape
    pieces = 10
    for _ in range(pieces):
        x = random.randint(0, width - 1)
        y = random.randint(0, height - 1)
        w = random.randint(1, width // 10)
        h = random.randint(1, height // 10)
        frame[y:y+h, x:x+w] = np.random.randint(0, 256, (h, w, 3), dtype=np.uint8)
    return frame

def pixelate_effect(frame):
    height, width, _ = frame.shape
    pixelated_frame = cv2.resize(frame, (width // 10, height // 10), interpolation=cv2.INTER_LINEAR)
    return cv2.resize(pixelated_frame, (width, height), interpolation=cv2.INTER_NEAREST)

if __name__ == "__main__":
    input_video = 'input.mp4'
    output_video = 'output.mp4'
    create_ytp_video(input_video, output_video)
