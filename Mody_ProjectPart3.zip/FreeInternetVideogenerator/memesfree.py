import wx
import os
from moviepy.editor import VideoFileClip, concatenate_videoclips

class MemeConcatenatorApp(wx.Frame):
    def __init__(self, *args, **kw):
        super(MemeConcatenatorApp, self).__init__(*args, **kw)
        
        self.InitUI()
        self.meme_files = []  # List to store meme video paths

    def InitUI(self):
        panel = wx.Panel(self)

        # Title
        vbox = wx.BoxSizer(wx.VERTICAL)
        title = wx.StaticText(panel, label="Automatic Meme Video Concatenator")
        font = title.GetFont()
        font.PointSize += 4
        font = font.Bold()
        title.SetFont(font)
        vbox.Add(title, flag=wx.ALIGN_CENTER | wx.TOP, border=10)

        # Add meme videos button
        add_memes_btn = wx.Button(panel, label='Add Meme Videos')
        add_memes_btn.Bind(wx.EVT_BUTTON, self.OnAddMemes)
        vbox.Add(add_memes_btn, flag=wx.EXPAND | wx.ALL, border=10)

        # Display selected meme files
        self.meme_listbox = wx.ListBox(panel)
        vbox.Add(self.meme_listbox, proportion=1, flag=wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, border=10)

        # Concatenate button
        concat_btn = wx.Button(panel, label='Concatenate Memes')
        concat_btn.Bind(wx.EVT_BUTTON, self.OnConcatenate)
        vbox.Add(concat_btn, flag=wx.EXPAND | wx.ALL, border=10)

        panel.SetSizer(vbox)

        self.SetTitle('Automatic Meme Concatenator')
        self.Centre()

    def OnAddMemes(self, event):
        """ Open file dialog to select meme video files """
        with wx.FileDialog(self, "Choose Meme Videos", wildcard="MP4 files (*.mp4)|*.mp4", 
                           style=wx.FD_OPEN | wx.FD_MULTIPLE) as fileDialog:
            if fileDialog.ShowModal() == wx.ID_CANCEL:
                return  # User cancelled the dialog
            
            paths = fileDialog.GetPaths()
            self.meme_files.extend(paths)
            
            # Update list box with selected files
            for path in paths:
                self.meme_listbox.Append(os.path.basename(path))

    def OnConcatenate(self, event):
        """ Concatenate selected meme videos and save the output """
        if not self.meme_files:
            wx.MessageBox('No meme videos selected!', 'Error', wx.OK | wx.ICON_ERROR)
            return
        
        try:
            # Load video clips
            clips = [VideoFileClip(meme) for meme in self.meme_files]
            final_clip = concatenate_videoclips(clips)

            # Save the concatenated video
            save_dialog = wx.FileDialog(self, "Save Concatenated Meme", wildcard="MP4 files (*.mp4)|*.mp4",
                                        style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT)
            if save_dialog.ShowModal() == wx.ID_CANCEL:
                return
            
            output_path = save_dialog.GetPath()
            final_clip.write_videofile(output_path, codec="libx264", audio_codec="aac")
            
            wx.MessageBox(f'Concatenated video saved to: {output_path}', 'Success', wx.OK | wx.ICON_INFORMATION)
        except Exception as e:
            wx.MessageBox(f'Error concatenating videos: {str(e)}', 'Error', wx.OK | wx.ICON_ERROR)

if __name__ == '__main__':
    app = wx.App(False)
    frame = MemeConcatenatorApp(None, size=(500, 400))
    frame.Show(True)
    app.MainLoop()
