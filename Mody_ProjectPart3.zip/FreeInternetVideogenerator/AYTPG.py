import tkinter as tk
from tkinter import filedialog
from moviepy.editor import VideoFileClip, concatenate_videoclips, AudioFileClip, CompositeVideoClip
from moviepy.video.fx import all as vfx
from moviepy.audio.fx import all as afx
import os

class YTPGeneratorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Automatic YTP Generator")
        
        self.video_files = []
        self.audio_files = []

        # GUI Elements
        self.create_widgets()

    def create_widgets(self):
        tk.Label(self.root, text="Select Video Files:").grid(row=0, column=0, padx=10, pady=5)
        tk.Button(self.root, text="Browse Videos", command=self.load_videos).grid(row=0, column=1, padx=10, pady=5)

        tk.Label(self.root, text="Select Audio Files:").grid(row=1, column=0, padx=10, pady=5)
        tk.Button(self.root, text="Browse Audios", command=self.load_audios).grid(row=1, column=1, padx=10, pady=5)

        tk.Label(self.root, text="Effects:").grid(row=2, column=0, padx=10, pady=5)
        self.effects_var = tk.StringVar(value="None")
        tk.OptionMenu(self.root, self.effects_var, "None", "Reverb", "Echo", "Speed Up", "Slow Down").grid(row=2, column=1, padx=10, pady=5)

        tk.Button(self.root, text="Generate Video", command=self.generate_video).grid(row=3, column=0, columnspan=2, pady=10)

        self.status = tk.Label(self.root, text="", fg="green")
        self.status.grid(row=4, column=0, columnspan=2, pady=10)

    def load_videos(self):
        files = filedialog.askopenfilenames(filetypes=[("Video Files", "*.mp4 *.avi *.mov")])
        self.video_files = list(files)
        self.status.config(text=f"Loaded {len(self.video_files)} video files")

    def load_audios(self):
        files = filedialog.askopenfilenames(filetypes=[("Audio Files", "*.mp3 *.wav")])
        self.audio_files = list(files)
        self.status.config(text=f"Loaded {len(self.audio_files)} audio files")

    def generate_video(self):
        if not self.video_files:
            self.status.config(text="No video files selected", fg="red")
            return

        clips = [VideoFileClip(f) for f in self.video_files]
        audio_clips = [AudioFileClip(f) for f in self.audio_files]

        # Concatenate video clips
        final_clip = concatenate_videoclips(clips)

        # Apply effects
        if self.effects_var.get() == "Reverb":
            final_clip = final_clip.fx(vfx.lum_contrast, contrast=1.5)
        elif self.effects_var.get() == "Echo":
            final_clip = final_clip.fx(vfx.colorx, factor=1.2)
        elif self.effects_var.get() == "Speed Up":
            final_clip = final_clip.fx(vfx.speedx, factor=1.5)
        elif self.effects_var.get() == "Slow Down":
            final_clip = final_clip.fx(vfx.speedx, factor=0.5)

        # Set audio
        if audio_clips:
            final_audio = concatenate_audioclips(audio_clips)
            final_clip = final_clip.set_audio(final_audio)

        # Save final video
        output_file = "ytp_generated.mp4"
        final_clip.write_videofile(output_file, codec='libx264', audio_codec='aac')

        self.status.config(text=f"Video generated: {output_file}", fg="green")

if __name__ == "__main__":
    root = tk.Tk()
    app = YTPGeneratorApp(root)
    root.mainloop()
