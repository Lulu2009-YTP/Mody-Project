import os
import random
import moviepy.editor as mp

def create_ytpmv_video(audio_file, image_folder, output_file, duration_per_image=2):
    audio = mp.AudioFileClip(audio_file)
    image_files = [os.path.join(image_folder, img) for img in os.listdir(image_folder) if img.endswith(('.png', '.jpg', '.jpeg'))]
    
    clips = []
    for img in image_files:
        img_clip = mp.ImageClip(img).set_duration(duration_per_image)
        clips.append(img_clip)

    video = mp.concatenate_videoclips(clips, method="compose")
    video = video.set_audio(audio)
    video.write_videofile(output_file, fps=24)

if __name__ == "__main__":
    audio_file = "path/to/your/audio.mp3"
    image_folder = "path/to/your/images"
    output_file = "output/ytpmv_video.mp4"
    
    create_ytpmv_video(audio_file, image_folder, output_file)
