import wx
import os
import glob
from moviepy.editor import VideoFileClip, concatenate_videoclips

class YTPMVGenerator(wx.Frame):
    def __init__(self, *args, **kw):
        super(YTPMVGenerator, self).__init__(*args, **kw)

        self.InitUI()

    def InitUI(self):
        # Create the form elements
        panel = wx.Panel(self)

        vbox = wx.BoxSizer(wx.VERTICAL)

        # Input Directory Selector
        hbox1 = wx.BoxSizer(wx.HORIZONTAL)
        self.dirPicker = wx.DirPickerCtrl(panel, message="Select Folder with Video Clips")
        hbox1.Add(self.dirPicker, proportion=1, flag=wx.EXPAND)
        vbox.Add(hbox1, flag=wx.EXPAND | wx.ALL, border=10)

        # Output File Path
        hbox2 = wx.BoxSizer(wx.HORIZONTAL)
        self.outputFile = wx.TextCtrl(panel, value="output.mp4")
        hbox2.Add(wx.StaticText(panel, label="Output File:"), flag=wx.RIGHT, border=8)
        hbox2.Add(self.outputFile, proportion=1)
        vbox.Add(hbox2, flag=wx.EXPAND | wx.ALL, border=10)

        # Concatenate Button
        hbox3 = wx.BoxSizer(wx.HORIZONTAL)
        self.concatButton = wx.Button(panel, label='Concatenate Videos')
        self.concatButton.Bind(wx.EVT_BUTTON, self.OnConcatenate)
        hbox3.Add(self.concatButton)
        vbox.Add(hbox3, flag=wx.ALIGN_CENTER | wx.ALL, border=10)

        # Set the panel layout
        panel.SetSizer(vbox)

        # Set up the frame
        self.SetTitle('YTPMV Automatic Concatenator')
        self.Centre()
        self.Show(True)

    def OnConcatenate(self, event):
        input_dir = self.dirPicker.GetPath()
        output_file = self.outputFile.GetValue()

        # Validate directory
        if not os.path.exists(input_dir):
            wx.MessageBox('Selected folder does not exist.', 'Error', wx.OK | wx.ICON_ERROR)
            return

        # Get all video files from the selected directory
        video_files = glob.glob(os.path.join(input_dir, "*.mp4")) + \
                      glob.glob(os.path.join(input_dir, "*.avi")) + \
                      glob.glob(os.path.join(input_dir, "*.mkv")) + \
                      glob.glob(os.path.join(input_dir, "*.mov"))

        if len(video_files) == 0:
            wx.MessageBox('No video files found in the selected folder.', 'Error', wx.OK | wx.ICON_ERROR)
            return

        # Sort video files alphabetically
        video_files.sort()

        # Load video clips
        clips = []
        for video_file in video_files:
            clip = VideoFileClip(video_file)
            clips.append(clip)

        # Concatenate all clips
        final_clip = concatenate_videoclips(clips)

        # Export the concatenated video
        final_clip.write_videofile(output_file, codec="libx264", audio_codec="aac")

        wx.MessageBox(f'Video concatenation complete.\nOutput file: {output_file}', 'Success', wx.OK | wx.ICON_INFORMATION)

def main():
    app = wx.App(False)
    frame = YTPMVGenerator(None)
    app.MainLoop()

if __name__ == '__main__':
    main()
