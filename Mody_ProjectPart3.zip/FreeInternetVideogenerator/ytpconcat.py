import wx
from moviepy.editor import *
import random

# Function to apply Poopism/Chaos/Extended/Glitch Effects
def apply_effects(video_clip):
    # Apply random effects
    effects = [lambda clip: clip.fx(vfx.speedx, random.uniform(0.5, 2.0)),
               lambda clip: clip.fx(vfx.colorx, random.uniform(0.5, 2.0)),
               lambda clip: clip.fx(vfx.lum_contrast, random.uniform(-0.5, 0.5), random.uniform(-0.5, 0.5)),
               lambda clip: clip.fx(vfx.fadein, duration=random.uniform(0.5, 2.0)),
               lambda clip: clip.fx(vfx.fadeout, duration=random.uniform(0.5, 2.0)),
               lambda clip: clip.fx(vfx.blackwhite)]
    random.shuffle(effects)

    for effect in effects:
        video_clip = effect(video_clip)
    return video_clip

class VideoEditorFrame(wx.Frame):
    def __init__(self, *args, **kw):
        super(VideoEditorFrame, self).__init__(*args, **kw)
        
        self.panel = wx.Panel(self)
        self.sizer = wx.BoxSizer(wx.VERTICAL)
        
        # File picker for input videos
        self.file_picker = wx.FilePickerCtrl(self.panel, message="Select Video Files", wildcard="Video files (*.mp4)|*.mp4", style=wx.FLP_MULTIPLE)
        self.sizer.Add(self.file_picker, 0, wx.EXPAND | wx.ALL, 5)
        
        # Output directory picker
        self.output_dir_picker = wx.DirPickerCtrl(self.panel, message="Select Output Directory")
        self.sizer.Add(self.output_dir_picker, 0, wx.EXPAND | wx.ALL, 5)
        
        # Button to start processing
        self.process_button = wx.Button(self.panel, label="Process Videos")
        self.sizer.Add(self.process_button, 0, wx.ALL | wx.CENTER, 5)
        self.process_button.Bind(wx.EVT_BUTTON, self.on_process)
        
        self.panel.SetSizer(self.sizer)
        self.Bind(wx.EVT_CLOSE, self.on_close)

    def on_process(self, event):
        video_files = self.file_picker.GetPaths()
        output_dir = self.output_dir_picker.GetPath()
        
        if not video_files or not output_dir:
            wx.MessageBox('Please select video files and an output directory.', 'Error', wx.OK | wx.ICON_ERROR)
            return
        
        clips = [VideoFileClip(file) for file in video_files]
        final_clip = concatenate_videoclips(clips, method="compose")
        
        # Apply effects
        final_clip = apply_effects(final_clip)
        
        # Set duration to 3 minutes if longer
        if final_clip.duration > 180:
            final_clip = final_clip.subclip(0, 180)
        
        output_file = wx.FileDialog(self, "Save File", defaultDir=output_dir, wildcard="MP4 files (*.mp4)|*.mp4", style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT)
        if output_file.ShowModal() == wx.ID_CANCEL:
            return
        
        output_path = output_file.GetPath()
        
        # Write the result to file
        final_clip.write_videofile(output_path, codec='libx264', audio_codec='aac')
        wx.MessageBox('Video processing completed.', 'Info', wx.OK | wx.ICON_INFORMATION)
    
    def on_close(self, event):
        self.Destroy()

def main():
    app = wx.App(False)
    frame = VideoEditorFrame(None, title="YTP Video Editor", size=(600, 400))
    frame.Show()
    app.MainLoop()

if __name__ == "__main__":
    main()
