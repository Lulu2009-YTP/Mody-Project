import os
import moviepy.editor as mp
from moviepy.video.fx.all import resize
from moviepy.video.tools.subtitles import SubtitlesClip
from PIL import Image, ImageDraw, ImageFont

def create_meme_image(text, image_path, output_path):
    base = Image.open(image_path).convert('RGBA')
    width, height = base.size
    draw = ImageDraw.Draw(base)
    
    font = ImageFont.truetype("arial.ttf", 40)
    text_width, text_height = draw.textsize(text, font=font)
    
    text_position = ((width - text_width) / 2, height - text_height - 10)
    draw.text(text_position, text, font=font, fill="white")
    
    base.save(output_path)

def create_meme_video(image_path, audio_path, output_path, meme_text):
    meme_image_path = "meme_image.png"
    create_meme_image(meme_text, image_path, meme_image_path)
    
    meme_clip = mp.ImageClip(meme_image_path).set_duration(10)
    audio_clip = mp.AudioFileClip(audio_path)
    
    final_video = meme_clip.set_audio(audio_clip)
    final_video.write_videofile(output_path, fps=24)

def main():
    image_path = "input_image.jpg"
    audio_path = "input_audio.mp3"
    output_path = "meme_parody_video.mp4"
    meme_text = "When you realize it's Monday!"
    
    create_meme_video(image_path, audio_path, output_path, meme_text)

if __name__ == "__main__":
    main()
