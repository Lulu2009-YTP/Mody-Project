import tkinter as tk
from tkinter import filedialog, messagebox
from moviepy.editor import VideoFileClip, AudioFileClip, concatenate_videoclips
from moviepy.audio.fx.all import audio_fadein, audio_fadeout
from moviepy.video.fx.all import speedx, mirror_x
import os

# YTPMV-Style Creator Class
class YTPMVFormApp:
    def __init__(self, root):
        self.root = root
        self.root.title("YTPMV Creator 2014 Style")
        
        # Input fields for video and audio
        self.video_label = tk.Label(root, text="Video File:")
        self.video_label.grid(row=0, column=0)
        self.video_entry = tk.Entry(root, width=40)
        self.video_entry.grid(row=0, column=1)
        self.video_browse = tk.Button(root, text="Browse", command=self.browse_video)
        self.video_browse.grid(row=0, column=2)

        self.audio_label = tk.Label(root, text="Audio File:")
        self.audio_label.grid(row=1, column=0)
        self.audio_entry = tk.Entry(root, width=40)
        self.audio_entry.grid(row=1, column=1)
        self.audio_browse = tk.Button(root, text="Browse", command=self.browse_audio)
        self.audio_browse.grid(row=1, column=2)

        # Speed control
        self.speed_label = tk.Label(root, text="Video Speed:")
        self.speed_label.grid(row=2, column=0)
        self.speed_var = tk.DoubleVar(value=1.0)
        self.speed_slider = tk.Scale(root, variable=self.speed_var, from_=0.1, to=3.0, resolution=0.1, orient=tk.HORIZONTAL)
        self.speed_slider.grid(row=2, column=1, columnspan=2)

        # Mirror effect checkbox
        self.mirror_var = tk.IntVar()
        self.mirror_check = tk.Checkbutton(root, text="Mirror Effect", variable=self.mirror_var)
        self.mirror_check.grid(row=3, column=0, columnspan=2)

        # Fade-in effect checkbox
        self.fadein_var = tk.IntVar()
        self.fadein_check = tk.Checkbutton(root, text="Audio Fade-in", variable=self.fadein_var)
        self.fadein_check.grid(row=4, column=0, columnspan=2)

        # Fade-out effect checkbox
        self.fadeout_var = tk.IntVar()
        self.fadeout_check = tk.Checkbutton(root, text="Audio Fade-out", variable=self.fadeout_var)
        self.fadeout_check.grid(row=5, column=0, columnspan=2)

        # Output file entry
        self.output_label = tk.Label(root, text="Output File (mp4):")
        self.output_label.grid(row=6, column=0)
        self.output_entry = tk.Entry(root, width=40)
        self.output_entry.grid(row=6, column=1)
        self.output_browse = tk.Button(root, text="Browse", command=self.browse_output)
        self.output_browse.grid(row=6, column=2)

        # Create video button
        self.create_button = tk.Button(root, text="Create YTPMV", command=self.create_ytpmv)
        self.create_button.grid(row=7, column=0, columnspan=3)

    def browse_video(self):
        video_path = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4 *.avi *.mov")])
        self.video_entry.insert(0, video_path)

    def browse_audio(self):
        audio_path = filedialog.askopenfilename(filetypes=[("Audio files", "*.mp3 *.wav")])
        self.audio_entry.insert(0, audio_path)

    def browse_output(self):
        output_path = filedialog.asksaveasfilename(defaultextension=".mp4", filetypes=[("MP4 files", "*.mp4")])
        self.output_entry.insert(0, output_path)

    def create_ytpmv(self):
        video_path = self.video_entry.get()
        audio_path = self.audio_entry.get()
        output_path = self.output_entry.get()

        if not video_path or not audio_path or not output_path:
            messagebox.showerror("Error", "Please provide all file paths!")
            return

        # Load video and audio
        try:
            video_clip = VideoFileClip(video_path)
            audio_clip = AudioFileClip(audio_path)
        except Exception as e:
            messagebox.showerror("Error", f"Error loading files: {str(e)}")
            return

        # Apply speed effect
        video_clip = video_clip.fx(speedx, self.speed_var.get())

        # Apply mirror effect
        if self.mirror_var.get() == 1:
            video_clip = video_clip.fx(mirror_x)

        # Add audio to video
        if self.fadein_var.get() == 1:
            audio_clip = audio_clip.fx(audio_fadein, 2.0)
        if self.fadeout_var.get() == 1:
            audio_clip = audio_clip.fx(audio_fadeout, 2.0)

        video_clip = video_clip.set_audio(audio_clip)

        # Save output
        try:
            video_clip.write_videofile(output_path, codec="libx264", audio_codec="aac")
            messagebox.showinfo("Success", f"YTPMV video created at {output_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Error saving video: {str(e)}")

# Main window setup
root = tk.Tk()
app = YTPMVFormApp(root)
root.mainloop()
