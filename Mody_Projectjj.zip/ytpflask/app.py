from flask import Flask, render_template, request, redirect, url_for, send_from_directory
from werkzeug.utils import secure_filename
import os
from moviepy.editor import VideoFileClip, concatenate_videoclips, vfx

app = Flask(__name__)

# Configurations for file uploads
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'mp4', 'avi', 'mov', 'jpg', 'png', 'mp3', 'wav'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure the upload folder exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Route for home page and form
@app.route('/')
def index():
    return render_template('index.html')

# Route to handle file uploads
@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return 'No file part'
    file = request.files['file']
    if file.filename == '':
        return 'No selected file'
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        return redirect(url_for('uploaded_file', filename=filename))
    return 'Invalid file type'

# Route to display uploaded file
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# Route to apply YTP effects (e.g., "poopism")
@app.route('/ytp/<filename>')
def apply_ytp_effect(filename):
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    
    if filename.endswith(('.mp4', '.avi', '.mov')):
        clip = VideoFileClip(file_path)
        
        # Apply some YTP-style effects (e.g., reversing, speeding up)
        modified_clip = clip.fx(vfx.time_mirror).fx(vfx.speedx, 2)
        
        output_path = os.path.join(app.config['UPLOAD_FOLDER'], 'ytp_' + filename)
        modified_clip.write_videofile(output_path)
        return redirect(url_for('uploaded_file', filename='ytp_' + filename))

    return 'Invalid file for YTP processing'

if __name__ == '__main__':
    app.run(debug=True)
