from flask import Flask, render_template, request, redirect, send_file
from moviepy.editor import VideoFileClip, AudioFileClip
from pydub import AudioSegment
import yt_dlp
import os

app = Flask(__name__)

# Folder to save temporary downloads
DOWNLOAD_FOLDER = './downloads'
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def process_media():
    youtube_url = request.form.get('youtube_url')
    file = request.files['file']
    
    # Process YouTube URL or uploaded file
    if youtube_url:
        video_path, audio_path = download_from_youtube(youtube_url)
    elif file:
        file_path = os.path.join(DOWNLOAD_FOLDER, file.filename)
        file.save(file_path)
        video_path, audio_path = process_uploaded_file(file_path)
    else:
        return "No media provided!", 400

    # Apply automatic pitch and YTPMV-style edits
    output_path = create_ytpmv(video_path, audio_path)

    return send_file(output_path, as_attachment=True)

def download_from_youtube(url):
    ydl_opts = {
        'format': 'best',
        'outtmpl': os.path.join(DOWNLOAD_FOLDER, '%(title)s.%(ext)s')
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info_dict = ydl.extract_info(url, download=True)
        video_path = ydl.prepare_filename(info_dict)
        audio_path = video_path.replace('.mp4', '.mp3')
        AudioSegment.from_file(video_path).export(audio_path, format="mp3")
        return video_path, audio_path

def process_uploaded_file(file_path):
    audio_path = file_path.replace('.mp4', '.mp3')
    AudioSegment.from_file(file_path).export(audio_path, format="mp3")
    return file_path, audio_path

def create_ytpmv(video_path, audio_path):
    # Load video and audio files
    video = VideoFileClip(video_path)
    audio = AudioSegment.from_file(audio_path)
    
    # Apply pitch shifting
    audio = audio_speed_change(audio, 1.5)  # Example: increase speed/pitch by 1.5x
    
    # Save the modified audio
    output_audio_path = audio_path.replace('.mp3', '_ytpmv.mp3')
    audio.export(output_audio_path, format="mp3")
    
    # Combine video and audio
    final_audio = AudioFileClip(output_audio_path)
    video = video.set_audio(final_audio)

    # Export the final YTPMV video
    output_video_path = video_path.replace('.mp4', '_ytpmv.mp4')
    video.write_videofile(output_video_path)
    
    return output_video_path

def audio_speed_change(audio, speed=1.0):
    new_audio = audio._spawn(audio.raw_data, overrides={"frame_rate": int(audio.frame_rate * speed)})
    return new_audio.set_frame_rate(audio.frame_rate)

if __name__ == '__main__':
    app.run(debug=True)
